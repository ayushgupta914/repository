
  # Multi Page Website Setup

  This is a code bundle for Multi Page Website Setup. The original project is available at https://www.figma.com/design/dnS0zpfoZJnb5upuXWIX2N/Multi-Page-Website-Setup.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
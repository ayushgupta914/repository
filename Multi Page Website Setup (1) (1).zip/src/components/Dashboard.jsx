import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Checkbox } from './ui/checkbox';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';
import { Input } from './ui/input';
import { Label } from './ui/label';

export function Dashboard({ user, recentPredictions = [], onPageChange }) {
  const [healthScore] = useState(78);
  const [isLocationDialogOpen, setIsLocationDialogOpen] = useState(false);
  const [selectedPredictions, setSelectedPredictions] = useState([]);
  const [userLocation, setUserLocation] = useState('');
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  const [locationError, setLocationError] = useState('');
  const [nearbyHospitals, setNearbyHospitals] = useState([]);

  // Mock ENT hospitals database organized by location
  const hospitalDatabase = {
    // Major US Cities
    "new york": [
      { name: "Manhattan ENT & Allergy Associates", address: "123 Park Avenue, New York, NY 10016", phone: "+1-212-555-0101", specialty: "ENT Surgery & Audiology" },
      { name: "NYC Eye and Ear Infirmary", address: "310 E 14th St, New York, NY 10003", phone: "+1-212-555-0102", specialty: "Comprehensive Eye, Ear & Throat Care" },
      { name: "Mount Sinai ENT Specialists", address: "1 Gustave L. Levy Pl, New York, NY 10029", phone: "+1-212-555-0103", specialty: "ENT Surgery & Sleep Medicine" }
    ],
    "los angeles": [
      { name: "UCLA ENT Department", address: "200 UCLA Medical Plaza, Los Angeles, CA 90095", phone: "+1-310-555-0201", specialty: "Advanced ENT Surgery" },
      { name: "Cedars-Sinai ENT Center", address: "8700 Beverly Blvd, Los Angeles, CA 90048", phone: "+1-310-555-0202", specialty: "ENT & Head/Neck Surgery" },
      { name: "LA Eye & ENT Clinic", address: "1245 Wilshire Blvd, Los Angeles, CA 90017", phone: "+1-213-555-0203", specialty: "Comprehensive ENT Care" }
    ],
    "chicago": [
      { name: "Northwestern Medicine ENT", address: "675 N St Clair St, Chicago, IL 60611", phone: "+1-312-555-0301", specialty: "ENT Surgery & Allergy" },
      { name: "Rush University ENT Department", address: "1653 W Congress Pkwy, Chicago, IL 60612", phone: "+1-312-555-0302", specialty: "Advanced ENT Procedures" },
      { name: "Chicago ENT Associates", address: "30 N Michigan Ave, Chicago, IL 60602", phone: "+1-312-555-0303", specialty: "ENT & Pulmonary Care" }
    ],
    "houston": [
      { name: "Houston Methodist ENT", address: "6550 Fannin St, Houston, TX 77030", phone: "+1-713-555-0401", specialty: "ENT Surgery & Sinus Care" },
      { name: "Texas ENT Specialists", address: "7900 Fannin St, Houston, TX 77054", phone: "+1-713-555-0402", specialty: "Comprehensive ENT Services" },
      { name: "Memorial Hermann ENT", address: "6411 Fannin St, Houston, TX 77030", phone: "+1-713-555-0403", specialty: "ENT & Head/Neck Surgery" }
    ],
    "miami": [
      { name: "Miami ENT Associates", address: "8940 N Kendall Dr, Miami, FL 33176", phone: "+1-305-555-0501", specialty: "ENT Surgery & Allergy" },
      { name: "University of Miami ENT", address: "1475 NW 12th Ave, Miami, FL 33136", phone: "+1-305-555-0502", specialty: "Advanced ENT Care" },
      { name: "South Florida ENT Center", address: "9195 Sunset Dr, Miami, FL 33173", phone: "+1-305-555-0503", specialty: "ENT & Sleep Disorders" }
    ],
    // International Cities
    "london": [
      { name: "Royal London Hospital ENT", address: "Whitechapel Rd, London E1 1BB, UK", phone: "+44-20-7377-7000", specialty: "NHS ENT Services" },
      { name: "Private Harley Street ENT", address: "123 Harley St, London W1G 6AX, UK", phone: "+44-20-7935-4444", specialty: "Private ENT Surgery" },
      { name: "Guy's Hospital ENT Department", address: "Great Maze Pond, London SE1 9RT, UK", phone: "+44-20-7188-7188", specialty: "Comprehensive ENT Care" }
    ],
    "toronto": [
      { name: "Toronto General Hospital ENT", address: "200 Elizabeth St, Toronto, ON M5G 2C4", phone: "+1-416-340-4800", specialty: "Advanced ENT Surgery" },
      { name: "Sunnybrook ENT Centre", address: "2075 Bayview Ave, Toronto, ON M4N 3M5", phone: "+1-416-480-6100", specialty: "ENT & Head/Neck Surgery" },
      { name: "Mount Sinai ENT Toronto", address: "600 University Ave, Toronto, ON M5G 1X5", phone: "+1-416-596-4200", specialty: "Comprehensive ENT Services" }
    ],
    "mumbai": [
      { name: "Kokilaben Dhirubhai Ambani Hospital", address: "Rao Saheb Achutrao Patwardhan Marg, Mumbai 400053", phone: "+91-22-4269-6969", specialty: "Advanced ENT Surgery" },
      { name: "Lilavati Hospital ENT", address: "A-791, Bandra Reclamation, Mumbai 400050", phone: "+91-22-2640-7777", specialty: "ENT & Head/Neck Surgery" },
      { name: "King Edward Memorial Hospital", address: "Acharya Donde Marg, Parel, Mumbai 400012", phone: "+91-22-2410-7000", specialty: "Government ENT Services" }
    ],
    "delhi": [
      { name: "All India Institute of Medical Sciences", address: "Sri Aurobindo Marg, New Delhi 110029", phone: "+91-11-2658-8500", specialty: "Government ENT Services" },
      { name: "Apollo Hospital ENT", address: "Sarita Vihar, New Delhi 110076", phone: "+91-11-2692-5858", specialty: "Private ENT Surgery" },
      { name: "Max Hospital ENT Department", address: "1-2, Press Enclave Rd, New Delhi 110017", phone: "+91-11-2651-5050", specialty: "Advanced ENT Care" }
    ],
    // Generic for smaller cities/towns
    "default": [
      { name: "Regional ENT Medical Center", address: "Main Street Medical Complex", phone: "+1-800-ENT-CARE", specialty: "General ENT Services" },
      { name: "Community Eye, Ear & Throat Clinic", address: "Downtown Healthcare District", phone: "+1-800-HEALTH-1", specialty: "Family ENT Care" },
      { name: "City General Hospital ENT Wing", address: "Central Hospital Campus", phone: "+1-800-HOSPITAL", specialty: "Emergency & Routine ENT" }
    ]
  };

  const upcomingReminders = [
    { id: 1, title: 'Annual Health Checkup', date: '2025-01-15', type: 'appointment' },
    { id: 2, title: 'Blood Pressure Check', date: '2025-01-10', type: 'self-monitor' },
    { id: 3, title: 'Medication Review', date: '2025-01-20', type: 'medication' }
  ];

  const healthTips = [
    'Stay hydrated - aim for 8 glasses of water daily',
    'Get 7-9 hours of quality sleep each night',
    'Exercise for at least 30 minutes, 5 days a week',
    'Eat a balanced diet rich in fruits and vegetables'
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'resolved': return 'bg-green-100 text-green-800';
      case 'monitoring': return 'bg-yellow-100 text-yellow-800';
      case 'urgent': return 'bg-red-100 text-red-800';
      case 'pending': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'severe': return 'bg-red-100 text-red-800';
      case 'moderate': return 'bg-yellow-100 text-yellow-800';
      case 'mild': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getReminderIcon = (type) => {
    switch (type) {
      case 'appointment': return '🏥';
      case 'self-monitor': return '📊';
      case 'medication': return '💊';
      default: return '📅';
    }
  };

  const getOrganIcon = (organ) => {
    switch (organ.toLowerCase()) {
      case 'ear': return '👂';
      case 'eyes': return '👁️';
      case 'lungs': return '🫁';
      default: return '🩺';
    }
  };

  const findHospitalsByLocation = (location) => {
    setLocationError('');
    
    if (!location.trim()) {
      setLocationError('Please enter your city/town name.');
      return;
    }

    const normalizedLocation = location.toLowerCase().trim();
    
    // First try exact match
    let hospitals = hospitalDatabase[normalizedLocation];
    
    // If no exact match, try partial matching for major cities
    if (!hospitals) {
      const partialMatch = Object.keys(hospitalDatabase).find(key => 
        key.includes(normalizedLocation) || normalizedLocation.includes(key)
      );
      
      if (partialMatch) {
        hospitals = hospitalDatabase[partialMatch];
      } else {
        // Use default hospitals for smaller cities/towns
        hospitals = hospitalDatabase.default.map(hospital => ({
          ...hospital,
          address: hospital.address.replace('Main Street Medical Complex', `${location} Medical Center, Main Street`)
            .replace('Downtown Healthcare District', `${location} Downtown Healthcare District`)
            .replace('Central Hospital Campus', `${location} General Hospital, Central Campus`)
        }));
      }
    }

    setNearbyHospitals(hospitals);
    setLocationError('');
  };

  const handlePredictionSelect = (predictionId) => {
    setSelectedPredictions(prev => 
      prev.includes(predictionId) 
        ? prev.filter(id => id !== predictionId)
        : [...prev, predictionId]
    );
  };

  const generatePDF = async () => {
    if (selectedPredictions.length === 0) {
      alert('Please select at least one prediction to download.');
      return;
    }

    setIsGeneratingPDF(true);

    // Simulate PDF generation delay
    setTimeout(() => {
      const selectedData = (user.predictions || []).filter(p => 
        selectedPredictions.includes(p.id)
      );

      // Create PDF content as text
      let pdfContent = `SYMPTOM DISEASE PREDICTOR - COMPREHENSIVE MEDICAL REPORT
========================================================

PATIENT INFORMATION:
-------------------
Name: ${user.username}
Email: ${user.email}
Sex: ${user.sex}
Blood Group: ${user.bloodGroup}
Mobile: ${user.mobile}
Report Generated: ${new Date().toLocaleString()}

`;

      if (userLocation && nearbyHospitals.length > 0) {
        pdfContent += `LOCATION-BASED ANALYSIS:
------------------------
Patient Location: ${userLocation}

NEAREST HOSPITALS & SPECIALISTS:
===============================
`;
        nearbyHospitals.slice(0, 3).forEach((hospital, index) => {
          pdfContent += `
${index + 1}. ${hospital.name}
   📍 Address: ${hospital.address}
   📞 Phone: ${hospital.phone}
   🏥 Specialty: ${hospital.specialty}
   
`;
        });
      }

      pdfContent += `
MEDICAL ANALYSES & PREDICTIONS:
===============================
`;

      selectedData.forEach((prediction, index) => {
        const symptoms = prediction.symptoms.map(symptom => `• ${symptom}`).join('\n');
        const recommendations = prediction.recommendations.map((rec, i) => `${i + 1}. ${rec}`).join('\n');
        
        pdfContent += `
ANALYSIS ${index + 1}:
===============
Date: ${prediction.date} at ${prediction.time}
Organ System: ${prediction.organ}

SYMPTOMS ANALYZED:
${symptoms}

PREDICTED DISEASE (HIGHEST CONFIDENCE):
---------------------------------------
🎯 Diagnosis: ${prediction.topCondition}
📊 Overall Confidence: ${prediction.probability}%
⚠️  Severity: ${prediction.severity.toUpperCase()}
📋 Current Status: ${prediction.status.toUpperCase()}

ML MODEL SCORES (Individual Predictions):
------------------------------------------
${prediction.modelScores ? (() => {
  const scores = {
    'Logistic Regression': prediction.modelScores.logisticRegression || 0,
    'Random Forest': prediction.modelScores.randomForest || 0,
    'Gradient Boosting': prediction.modelScores.gradientBoosting || 0
  };
  let highestScore = Math.max(...Object.values(scores));
  let highestModel = Object.entries(scores).find(([_, score]) => score === highestScore)?.[0] || '';
  
  return `
• Logistic Regression: ${prediction.modelScores.logisticRegression}%${prediction.modelScores.logisticRegression === highestScore ? ' ⭐ HIGHEST ACCURACY' : ''}
• Random Forest: ${prediction.modelScores.randomForest}%${prediction.modelScores.randomForest === highestScore ? ' ⭐ HIGHEST ACCURACY' : ''}
• Gradient Boosting: ${prediction.modelScores.gradientBoosting}%${prediction.modelScores.gradientBoosting === highestScore ? ' ⭐ HIGHEST ACCURACY' : ''}

🏆 HIGHEST PERFORMING MODEL: ${highestModel} (${highestScore}%)

Ensemble Method: Weighted Average
Note: The diagnosis "${prediction.topCondition}" represents the highest 
confidence prediction with ${highestScore}% accuracy from ${highestModel}.
All three models (Logistic Regression, Random Forest, and Gradient Boosting) 
were used to ensure accurate disease prediction.
`;
})() : 'Model scores not available for this prediction.'}

CLINICAL RECOMMENDATIONS:
-------------------------
${recommendations}

**************************************************

`;
      });

      pdfContent += `
MEDICAL DISCLAIMER:
==================
This report is generated by an AI-powered symptom checker and is for informational purposes only. 
It should not replace professional medical diagnosis, treatment, or advice. Always consult with 
qualified healthcare providers for proper medical evaluation and treatment decisions.

For emergencies, contact your local emergency services immediately.

Report ID: ${Date.now()}
© 2024 Symptom Disease Predictor Platform
`;

      // Create and download the text file
      const blob = new Blob([pdfContent], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `Medical_Report_${user.username}_${new Date().toISOString().split('T')[0]}.txt`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      setIsGeneratingPDF(false);
      setIsLocationDialogOpen(false);
      setSelectedPredictions([]);
      alert('Medical report downloaded successfully!');
    }, 3000);
  };

  const handleDownloadData = () => {
    setSelectedPredictions([]);
    setUserLocation('');
    setNearbyHospitals([]);
    setLocationError('');
    setIsLocationDialogOpen(true);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Welcome Header */}
        <div className="mb-8">
          <h1 className="text-gray-900">
            Welcome back, {user.username}! 👋
          </h1>
          <p className="mt-2 text-gray-600">
            Here's an overview of your health journey and recent activity.
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <span className="text-2xl">🩺</span>
                </div>
                <div className="ml-4">
                  <p className="text-gray-900">{user.predictions?.length || 0}</p>
                  <p className="text-gray-600">Total Analyses</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-2 bg-green-100 rounded-lg">
                  <span className="text-2xl">💚</span>
                </div>
                <div className="ml-4">
                  <p className="text-gray-900">{healthScore}%</p>
                  <p className="text-gray-600">Health Score</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-2 bg-yellow-100 rounded-lg">
                  <span className="text-2xl">⏰</span>
                </div>
                <div className="ml-4">
                  <p className="text-gray-900">{upcomingReminders.length}</p>
                  <p className="text-gray-600">Reminders</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-2 bg-purple-100 rounded-lg">
                  <span className="text-2xl">🔬</span>
                </div>
                <div className="ml-4">
                  <p className="text-gray-900">{user.bloodGroup}</p>
                  <p className="text-gray-600">Blood Group</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="analyses">Recent Analyses</TabsTrigger>
            <TabsTrigger value="reminders">Reminders</TabsTrigger>
            <TabsTrigger value="profile">Profile</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Health Score */}
              <Card>
                <CardHeader>
                  <CardTitle>Health Score</CardTitle>
                  <CardDescription>
                    Based on your recent analyses and health data
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span>Overall Health</span>
                      <span>{healthScore}%</span>
                    </div>
                    <Progress value={healthScore} className="w-full" />
                    <p className="text-gray-600">
                      {healthScore >= 80 ? 'Excellent! Keep up the good work.' :
                       healthScore >= 60 ? 'Good health status. Consider lifestyle improvements.' :
                       'Consider consulting with a healthcare provider.'}
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                  <CardDescription>
                    Common tasks you might want to perform
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button 
                    onClick={() => onPageChange('symptom-checker')}
                    className="w-full justify-start"
                    variant="outline"
                  >
                    🩺 New Symptom Analysis
                  </Button>
                  <Button 
                    onClick={() => {/* Handle health tracking */}}
                    className="w-full justify-start"
                    variant="outline"
                  >
                    📊 Track Health Metrics
                  </Button>
                  <Button 
                    onClick={() => {/* Handle appointment booking */}}
                    className="w-full justify-start"
                    variant="outline"
                  >
                    📅 Book Appointment
                  </Button>
                  <Button 
                    onClick={() => {/* Handle emergency contacts */}}
                    className="w-full justify-start"
                    variant="outline"
                  >
                    🚨 Emergency Contacts
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Recent Analysis - Shows predictions made after login */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Analysis</CardTitle>
                <CardDescription>
                  Latest symptom predictions from this session (highest confidence)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentPredictions && recentPredictions.length > 0 ? (
                    recentPredictions.slice(0, 3).map((prediction) => {
                      // Calculate highest model score
                      const modelScores = prediction.modelScores || {};
                      const scores = [
                        modelScores.logisticRegression || 0,
                        modelScores.randomForest || 0,
                        modelScores.gradientBoosting || 0
                      ];
                      const highestScore = Math.max(...scores);
                      
                      return (
                        <div key={prediction.id} className="p-4 border-2 border-blue-200 bg-blue-50 rounded-lg hover:border-blue-400 transition-colors">
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex items-center space-x-3">
                              <span className="text-3xl">{getOrganIcon(prediction.organ)}</span>
                              <div>
                                <p className="text-gray-900">{prediction.topCondition}</p>
                                <p className="text-gray-600">{prediction.date} at {prediction.time}</p>
                              </div>
                            </div>
                            <div className="flex flex-col items-end space-y-2">
                              <Badge className={getStatusColor(prediction.status)}>
                                {prediction.status}
                              </Badge>
                              <div className="bg-green-600 text-white px-3 py-1 rounded-lg">
                                <span>{highestScore}% Highest Accuracy</span>
                              </div>
                            </div>
                          </div>
                          
                          {/* ML Model Scores */}
                          <div className="grid grid-cols-3 gap-2 mb-3">
                            <div className={`p-3 rounded text-center ${modelScores.logisticRegression === highestScore ? 'bg-green-100 border-2 border-green-500' : 'bg-blue-100'}`}>
                              <div className={modelScores.logisticRegression === highestScore ? 'text-green-700' : 'text-blue-700'}>Logistic Regression</div>
                              <div className={`${modelScores.logisticRegression === highestScore ? 'text-green-900' : 'text-blue-900'}`}>
                                {modelScores.logisticRegression || 'N/A'}%
                              </div>
                            </div>
                            <div className={`p-3 rounded text-center ${modelScores.randomForest === highestScore ? 'bg-green-100 border-2 border-green-500' : 'bg-green-50'}`}>
                              <div className={modelScores.randomForest === highestScore ? 'text-green-700' : 'text-green-600'}>Random Forest</div>
                              <div className={`${modelScores.randomForest === highestScore ? 'text-green-900' : 'text-green-800'}`}>
                                {modelScores.randomForest || 'N/A'}%
                              </div>
                            </div>
                            <div className={`p-3 rounded text-center ${modelScores.gradientBoosting === highestScore ? 'bg-green-100 border-2 border-green-500' : 'bg-purple-50'}`}>
                              <div className={modelScores.gradientBoosting === highestScore ? 'text-green-700' : 'text-purple-700'}>Gradient Boosting</div>
                              <div className={`${modelScores.gradientBoosting === highestScore ? 'text-green-900' : 'text-purple-900'}`}>
                                {modelScores.gradientBoosting || 'N/A'}%
                              </div>
                            </div>
                          </div>

                          {/* Additional Info */}
                          <div className="flex items-center justify-between mt-3 pt-3 border-t border-blue-200">
                            <div className="flex items-center space-x-3">
                              <Badge className={getSeverityColor(prediction.severity)}>
                                {prediction.severity}
                              </Badge>
                              <span className="text-gray-600">• {prediction.organ} System</span>
                            </div>
                            <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">
                              {prediction.probability}% confidence
                            </span>
                          </div>

                          {/* Symptoms */}
                          <div className="mt-3 pt-3 border-t border-blue-200">
                            <p className="text-gray-700">
                              <strong>Symptoms:</strong> {prediction.symptoms.join(', ')}
                            </p>
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <div className="text-center py-12 text-gray-500">
                      <span className="text-6xl mb-4 block">🔍</span>
                      <p>No recent predictions yet</p>
                      <p className="mt-2">Start by using the Symptom Checker to analyze your symptoms!</p>
                      <Button 
                        onClick={() => onPageChange('symptom-checker')}
                        className="mt-4"
                      >
                        Analyze Symptoms Now
                      </Button>
                    </div>
                  )}
                </div>
                
                {recentPredictions && recentPredictions.length > 3 && (
                  <div className="mt-4 text-center">
                    <p className="text-gray-600 mb-3">Showing {Math.min(3, recentPredictions.length)} of {recentPredictions.length} recent predictions</p>
                    <Button 
                      variant="outline"
                      onClick={() => {
                        const analysesTab = document.querySelector('[value="analyses"]');
                        if (analysesTab) analysesTab.click();
                      }}
                    >
                      View All Predictions →
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Health Tips */}
            <Card>
              <CardHeader>
                <CardTitle>Daily Health Tips</CardTitle>
                <CardDescription>
                  Personalized recommendations for better health
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {healthTips.map((tip, index) => (
                    <div key={index} className="flex items-start space-x-3 p-3 bg-blue-50 rounded-lg">
                      <span className="text-blue-600 mt-1">💡</span>
                      <p className="text-blue-800">{tip}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analyses" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Symptom Analyses</CardTitle>
                <CardDescription>
                  Your past symptom checks and their results
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {user.predictions && user.predictions.length > 0 ? (
                    user.predictions.map((prediction) => (
                      <div key={prediction.id} className="p-4 border border-gray-200 rounded-lg">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <span className="text-2xl">{getOrganIcon(prediction.organ)}</span>
                              <span>{prediction.date} at {prediction.time}</span>
                              <Badge className={getStatusColor(prediction.status)}>
                                {prediction.status}
                              </Badge>
                              <Badge className={getSeverityColor(prediction.severity)}>
                                {prediction.severity}
                              </Badge>
                            </div>
                            <p className="text-gray-600 mb-2">
                              <strong>Organ:</strong> {prediction.organ} | <strong>Symptoms:</strong> {prediction.symptoms.join(', ')}
                            </p>
                            <p>
                              <strong>Top Condition:</strong> {prediction.topCondition} ({prediction.probability}% match)
                            </p>
                          </div>
                          <div className="flex flex-col space-y-2">
                            <Button variant="outline" size="sm">
                              View Details
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <span className="text-4xl mb-4 block">🔍</span>
                      <p>No analyses found. Start by using the Symptom Checker!</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reminders" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Upcoming Reminders</CardTitle>
                <CardDescription>
                  Important health-related tasks and appointments
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {upcomingReminders.map((reminder) => (
                    <div key={reminder.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <span className="text-2xl">{getReminderIcon(reminder.type)}</span>
                        <div>
                          <p>{reminder.title}</p>
                          <p className="text-gray-600">{reminder.date}</p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">
                        Manage
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="profile" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Personal Information</CardTitle>
                  <CardDescription>
                    Your account and health profile details
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-gray-600">Username</p>
                      <p>{user.username}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Email</p>
                      <p>{user.email}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Sex</p>
                      <p className="capitalize">{user.sex}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Blood Group</p>
                      <p>{user.bloodGroup}</p>
                    </div>
                    <div className="col-span-2">
                      <p className="text-gray-600">Mobile</p>
                      <p>{user.mobile}</p>
                    </div>
                  </div>
                  <Button variant="outline" className="w-full">
                    Edit Profile
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Account Settings</CardTitle>
                  <CardDescription>
                    Manage your account preferences and privacy
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span>Email Notifications</span>
                      <input type="checkbox" defaultChecked className="h-4 w-4" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span>SMS Reminders</span>
                      <input type="checkbox" defaultChecked className="h-4 w-4" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Data Sharing</span>
                      <input type="checkbox" className="h-4 w-4" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full">
                      Change Password
                    </Button>
                    <Dialog open={isLocationDialogOpen} onOpenChange={setIsLocationDialogOpen}>
                      <DialogTrigger asChild>
                        <Button variant="outline" className="w-full" onClick={handleDownloadData}>
                          📄 Download Medical Report
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                        <DialogHeader>
                          <DialogTitle>Download Medical Report</DialogTitle>
                          <DialogDescription>
                            Select your predictions to include in the report. Enter your city/town name to find nearby hospitals.
                          </DialogDescription>
                        </DialogHeader>
                        
                        <div className="space-y-6">
                          {/* Location Section */}
                          <div className="space-y-4">
                            <h3>📍 Your Location</h3>
                            <p className="text-gray-600">
                              Enter your city, town, or village name to find nearby hospitals.
                            </p>
                            
                            <div className="space-y-3">
                              <Label htmlFor="location-input">City/Town/Village Name</Label>
                              <div className="flex space-x-2">
                                <Input
                                  id="location-input"
                                  placeholder="e.g., New York, London, Mumbai, Chicago..."
                                  value={userLocation}
                                  onChange={(e) => setUserLocation(e.target.value)}
                                  className="flex-1"
                                />
                                <Button 
                                  onClick={() => findHospitalsByLocation(userLocation)} 
                                  variant="outline"
                                  disabled={!userLocation.trim()}
                                >
                                  🔍 Find Hospitals
                                </Button>
                              </div>
                            </div>
                            
                            {locationError && (
                              <Alert>
                                <AlertDescription className="text-red-600">
                                  {locationError}
                                </AlertDescription>
                              </Alert>
                            )}
                            
                            {nearbyHospitals.length > 0 && (
                              <Alert>
                                <AlertDescription className="text-green-600">
                                  ✅ Found {nearbyHospitals.length} hospitals in {userLocation}! They will be included in your report.
                                </AlertDescription>
                              </Alert>
                            )}
                          </div>

                          <Separator />

                          {/* Predictions Selection */}
                          <div className="space-y-4">
                            <h3>📋 Select Predictions to Include</h3>
                            <p className="text-gray-600">
                              Choose which medical analyses to include in your downloadable report.
                            </p>
                            
                            {user.predictions && user.predictions.length > 0 ? (
                              <div className="space-y-3 max-h-60 overflow-y-auto">
                                {user.predictions.map((prediction) => (
                                  <div key={prediction.id} className="flex items-start space-x-3 p-3 border rounded-lg">
                                    <Checkbox
                                      checked={selectedPredictions.includes(prediction.id)}
                                      onCheckedChange={() => handlePredictionSelect(prediction.id)}
                                      className="mt-1"
                                    />
                                    <div className="flex-1">
                                      <div className="flex items-center space-x-2 mb-1">
                                        <span className="text-lg">{getOrganIcon(prediction.organ)}</span>
                                        <span>{prediction.date} - {prediction.organ}</span>
                                        <Badge className={getSeverityColor(prediction.severity)} variant="outline">
                                          {prediction.severity}
                                        </Badge>
                                      </div>
                                      <p className="text-gray-600">
                                        <strong>{prediction.topCondition}</strong> ({prediction.probability}% match)
                                      </p>
                                      <p className="text-gray-500">
                                        Symptoms: {prediction.symptoms.join(', ')}
                                      </p>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <p className="text-center text-gray-500 py-4">
                                No predictions available to download.
                              </p>
                            )}
                          </div>

                          {/* Nearby Hospitals Preview */}
                          {nearbyHospitals.length > 0 && (
                            <>
                              <Separator />
                              <div className="space-y-4">
                                <h3>🏥 Nearby Hospitals (Preview)</h3>
                                <p className="text-gray-600">
                                  These hospitals in {userLocation} will be included in your report.
                                </p>
                                <div className="space-y-2 max-h-40 overflow-y-auto">
                                  {nearbyHospitals.slice(0, 3).map((hospital, index) => (
                                    <div key={index} className="p-2 bg-gray-50 rounded">
                                      <div>{hospital.name}</div>
                                      <div className="text-gray-600">{hospital.phone}</div>
                                      <div className="text-gray-500">{hospital.specialty}</div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </>
                          )}

                          <Separator />

                          {/* Action Buttons */}
                          <div className="flex space-x-3">
                            <Button 
                              onClick={generatePDF}
                              disabled={isGeneratingPDF || selectedPredictions.length === 0}
                              className="flex-1"
                            >
                              {isGeneratingPDF ? (
                                <>
                                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                                  Generating Report...
                                </>
                              ) : (
                                '📄 Generate & Download Report'
                              )}
                            </Button>
                            <Button 
                              variant="outline" 
                              onClick={() => setIsLocationDialogOpen(false)}
                              disabled={isGeneratingPDF}
                            >
                              Cancel
                            </Button>
                          </div>

                          <Alert>
                            <AlertDescription>
                              <strong>Privacy Notice:</strong> Your location data is used only to find nearby hospitals and is not stored or shared. The generated report contains your selected medical data and should be handled securely.
                            </AlertDescription>
                          </Alert>
                        </div>
                      </DialogContent>
                    </Dialog>
                    <Button variant="destructive" className="w-full">
                      Delete Account
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
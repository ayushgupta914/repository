import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Alert, AlertDescription } from './ui/alert';

interface Hospital {
  id: string;
  name: string;
  address: string;
  distance: number;
  rating: number;
  speciality: string;
  phone?: string;
  website?: string;
  lat: number;
  lng: number;
  isOpen?: boolean;
  openingHours?: string;
}

interface HospitalLocatorProps {
  organType: 'ear' | 'eyes' | 'lungs';
}

export function HospitalLocator({ organType }: HospitalLocatorProps) {
  const [userLocationText, setUserLocationText] = useState<string>('');
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Find hospitals by location text
  const findHospitalsByLocation = (location: string) => {
    if (!location.trim()) {
      setError('Please enter your city/town name.');
      return;
    }

    setLoading(true);
    setError(null);

    // Simulate API delay
    setTimeout(() => {
      const mockHospitals: Hospital[] = getMockHospitalsByLocation(location, organType);
      setHospitals(mockHospitals);
      setLoading(false);
    }, 1500);
  };

  // Mock hospital data generator by location
  const getMockHospitalsByLocation = (location: string, type: string): Hospital[] => {
    // Comprehensive hospital database organized by location and organ type
    const hospitalDatabase: { [key: string]: { [key in 'ear' | 'eyes' | 'lungs']: any[] } } = {
      "new york": {
        ear: [
          { name: 'Manhattan ENT & Allergy Associates', speciality: 'ENT Surgery & Audiology', rating: 4.9, address: '123 Park Avenue, New York, NY 10016', phone: '+1-212-555-0101' },
          { name: 'NYC Eye and Ear Infirmary', speciality: 'Comprehensive Eye, Ear & Throat Care', rating: 4.8, address: '310 E 14th St, New York, NY 10003', phone: '+1-212-555-0102' },
          { name: 'Mount Sinai ENT Specialists', speciality: 'ENT Surgery & Sleep Medicine', rating: 4.7, address: '1 Gustave L. Levy Pl, New York, NY 10029', phone: '+1-212-555-0103' },
          { name: 'NewYork-Presbyterian ENT', speciality: 'Advanced ENT Surgery', rating: 4.6, address: '525 E 68th St, New York, NY 10065', phone: '+1-212-555-0104' },
          { name: 'Columbia ENT Associates', speciality: 'Hearing Disorders & Balance', rating: 4.5, address: '161 Fort Washington Ave, New York, NY 10032', phone: '+1-212-555-0105' }
        ],
        eyes: [
          { name: 'Manhattan Eye, Ear and Throat Hospital', speciality: 'Comprehensive Ophthalmology', rating: 4.9, address: '210 E 64th St, New York, NY 10065', phone: '+1-212-555-0201' },
          { name: 'New York Eye and Ear Infirmary', speciality: 'Retinal Surgery & Vision Care', rating: 4.8, address: '310 E 14th St, New York, NY 10003', phone: '+1-212-555-0202' },
          { name: 'Columbia Ophthalmology', speciality: 'Laser Eye Surgery', rating: 4.7, address: '635 W 165th St, New York, NY 10032', phone: '+1-212-555-0203' },
          { name: 'NYU Langone Eye Center', speciality: 'Pediatric Ophthalmology', rating: 4.6, address: '222 E 41st St, New York, NY 10017', phone: '+1-212-555-0204' },
          { name: 'Vitreous Retina Macula Consultants', speciality: 'Retinal Disorders', rating: 4.8, address: '460 Park Ave, New York, NY 10022', phone: '+1-212-555-0205' }
        ],
        lungs: [
          { name: 'Mount Sinai Pulmonary Medicine', speciality: 'Advanced Pulmonology', rating: 4.8, address: '1 Gustave L. Levy Pl, New York, NY 10029', phone: '+1-212-555-0301' },
          { name: 'NewYork-Presbyterian Lung Center', speciality: 'Respiratory Therapy & COPD', rating: 4.7, address: '525 E 68th St, New York, NY 10065', phone: '+1-212-555-0302' },
          { name: 'Columbia Pulmonary & Critical Care', speciality: 'Sleep Medicine & Asthma', rating: 4.6, address: '161 Fort Washington Ave, New York, NY 10032', phone: '+1-212-555-0303' },
          { name: 'NYU Langone Pulmonology', speciality: 'Thoracic Medicine', rating: 4.5, address: '222 E 41st St, New York, NY 10017', phone: '+1-212-555-0304' },
          { name: 'Weill Cornell Lung Center', speciality: 'Interventional Pulmonology', rating: 4.4, address: '525 E 68th St, New York, NY 10065', phone: '+1-212-555-0305' }
        ]
      },
      "los angeles": {
        ear: [
          { name: 'UCLA ENT Department', speciality: 'Advanced ENT Surgery', rating: 4.8, address: '200 UCLA Medical Plaza, Los Angeles, CA 90095', phone: '+1-310-555-0401' },
          { name: 'Cedars-Sinai ENT Center', speciality: 'ENT & Head/Neck Surgery', rating: 4.7, address: '8700 Beverly Blvd, Los Angeles, CA 90048', phone: '+1-310-555-0402' },
          { name: 'USC ENT Associates', speciality: 'Hearing & Balance Disorders', rating: 4.6, address: '1520 San Pablo St, Los Angeles, CA 90033', phone: '+1-323-555-0403' }
        ],
        eyes: [
          { name: 'Doheny Eye Institute', speciality: 'Retinal Surgery & Research', rating: 4.9, address: '1450 San Pablo St, Los Angeles, CA 90033', phone: '+1-323-555-0501' },
          { name: 'UCLA Jules Stein Eye Institute', speciality: 'Comprehensive Ophthalmology', rating: 4.8, address: '100 Stein Plaza, Los Angeles, CA 90095', phone: '+1-310-555-0502' },
          { name: 'Cedars-Sinai Eye Center', speciality: 'Laser Vision Correction', rating: 4.7, address: '8700 Beverly Blvd, Los Angeles, CA 90048', phone: '+1-310-555-0503' }
        ],
        lungs: [
          { name: 'UCLA Pulmonary & Critical Care', speciality: 'Advanced Pulmonology', rating: 4.8, address: '200 UCLA Medical Plaza, Los Angeles, CA 90095', phone: '+1-310-555-0601' },
          { name: 'Cedars-Sinai Lung Center', speciality: 'Respiratory Medicine', rating: 4.7, address: '8700 Beverly Blvd, Los Angeles, CA 90048', phone: '+1-310-555-0602' },
          { name: 'USC Pulmonary Associates', speciality: 'Sleep Medicine & Asthma', rating: 4.6, address: '1520 San Pablo St, Los Angeles, CA 90033', phone: '+1-323-555-0603' }
        ]
      },
      "london": {
        ear: [
          { name: 'Royal London Hospital ENT', speciality: 'NHS ENT Services', rating: 4.6, address: 'Whitechapel Rd, London E1 1BB, UK', phone: '+44-20-7377-7000' },
          { name: 'Private Harley Street ENT', speciality: 'Private ENT Surgery', rating: 4.8, address: '123 Harley St, London W1G 6AX, UK', phone: '+44-20-7935-4444' },
          { name: 'Guy\'s Hospital ENT Department', speciality: 'Comprehensive ENT Care', rating: 4.5, address: 'Great Maze Pond, London SE1 9RT, UK', phone: '+44-20-7188-7188' }
        ],
        eyes: [
          { name: 'Moorfields Eye Hospital', speciality: 'World-Class Eye Care', rating: 4.9, address: '162 City Rd, London EC1V 2PD, UK', phone: '+44-20-7253-3411' },
          { name: 'Western Eye Hospital', speciality: 'Emergency Eye Care', rating: 4.6, address: '153-173 Marylebone Rd, London NW1 5QH, UK', phone: '+44-20-3312-6666' },
          { name: 'Royal London Hospital Eye Unit', speciality: 'Comprehensive Ophthalmology', rating: 4.5, address: 'Whitechapel Rd, London E1 1BB, UK', phone: '+44-20-7377-7000' }
        ],
        lungs: [
          { name: 'Royal Brompton Hospital', speciality: 'Leading Respiratory Care', rating: 4.8, address: 'Sydney St, London SW3 6NP, UK', phone: '+44-20-7352-8121' },
          { name: 'Guy\'s Hospital Respiratory', speciality: 'Pulmonary Medicine', rating: 4.6, address: 'Great Maze Pond, London SE1 9RT, UK', phone: '+44-20-7188-7188' },
          { name: 'St Bartholomew\'s Lung Centre', speciality: 'Advanced Lung Care', rating: 4.7, address: 'West Smithfield, London EC1A 7BE, UK', phone: '+44-20-7377-7000' }
        ]
      }
    };

    const normalizedLocation = location.toLowerCase().trim();
    
    // Find matching hospitals
    let locationHospitals = hospitalDatabase[normalizedLocation];
    
    // If no exact match, try partial matching
    if (!locationHospitals) {
      const partialMatch = Object.keys(hospitalDatabase).find(key => 
        key.includes(normalizedLocation) || normalizedLocation.includes(key)
      );
      
      if (partialMatch) {
        locationHospitals = hospitalDatabase[partialMatch];
      } else {
        // Use generic hospitals for unknown locations
        locationHospitals = {
          ear: [
            { name: `${location} ENT Medical Center`, speciality: 'General ENT Services', rating: 4.3, address: `Main Street Medical Complex, ${location}`, phone: '+1-800-ENT-CARE' },
            { name: `${location} Hearing & Balance Clinic`, speciality: 'Audiology Services', rating: 4.2, address: `Downtown Healthcare District, ${location}`, phone: '+1-800-HEARING' },
            { name: `${location} General Hospital ENT Wing`, speciality: 'Emergency & Routine ENT', rating: 4.1, address: `Central Hospital Campus, ${location}`, phone: '+1-800-HOSPITAL' }
          ],
          eyes: [
            { name: `${location} Vision Care Center`, speciality: 'Comprehensive Eye Care', rating: 4.4, address: `Main Street Medical Complex, ${location}`, phone: '+1-800-EYE-CARE' },
            { name: `${location} Eye Surgery Institute`, speciality: 'Eye Surgery & Laser Care', rating: 4.3, address: `Downtown Healthcare District, ${location}`, phone: '+1-800-EYE-SURG' },
            { name: `${location} Community Eye Clinic`, speciality: 'Family Eye Care', rating: 4.2, address: `Central Hospital Campus, ${location}`, phone: '+1-800-VISION' }
          ],
          lungs: [
            { name: `${location} Pulmonary Medicine Center`, speciality: 'Respiratory Care', rating: 4.3, address: `Main Street Medical Complex, ${location}`, phone: '+1-800-LUNG-CARE' },
            { name: `${location} Respiratory Health Clinic`, speciality: 'Asthma & COPD Care', rating: 4.2, address: `Downtown Healthcare District, ${location}`, phone: '+1-800-BREATHE' },
            { name: `${location} Sleep & Breathing Center`, speciality: 'Sleep Medicine', rating: 4.1, address: `Central Hospital Campus, ${location}`, phone: '+1-800-SLEEP' }
          ]
        };
      }
    }

    const organHospitals = locationHospitals[type as keyof typeof locationHospitals] || [];
    
    return organHospitals.map((hospital, index) => ({
      id: `${type}-${normalizedLocation}-${index}`,
      name: hospital.name,
      address: hospital.address,
      distance: Math.round((Math.random() * 8 + 1) * 10) / 10, // 1-9 km
      rating: hospital.rating,
      speciality: hospital.speciality,
      phone: hospital.phone,
      website: `www.${hospital.name.toLowerCase().replace(/\s+/g, '').replace(/&/g, 'and').replace(/[^a-z0-9]/g, '')}.com`,
      lat: 40.7128 + (Math.random() - 0.5) * 0.1, // Mock coordinates around NYC
      lng: -74.0060 + (Math.random() - 0.5) * 0.1,
      isOpen: Math.random() > 0.2, // 80% chance of being open
      openingHours: Math.random() > 0.5 ? '24/7' : '8:00 AM - 6:00 PM'
    })).sort((a, b) => a.distance - b.distance);
  };

  const getOrganDisplayName = (organ: string) => {
    switch (organ) {
      case 'ear': return 'Ear, Nose & Throat (ENT)';
      case 'eyes': return 'Eye Care & Ophthalmology';
      case 'lungs': return 'Pulmonary & Respiratory';
      default: return 'Medical';
    }
  };

  const getOrganIcon = (organ: string) => {
    switch (organ) {
      case 'ear': return '👂';
      case 'eyes': return '👁️';
      case 'lungs': return '🫁';
      default: return '🏥';
    }
  };

  return (
    <Card className="mt-6">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <span>{getOrganIcon(organType)}</span>
          <span>Find Nearby Hospitals</span>
        </CardTitle>
        <CardDescription>
          Find {getOrganDisplayName(organType)} specialists in your city or town
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {hospitals.length === 0 && !loading && (
          <div className="space-y-4">
            <div className="text-center py-6">
              <div className="text-4xl mb-4">📍</div>
              <h3 className="font-semibold mb-2">Find {getOrganDisplayName(organType)} Specialists</h3>
              <p className="text-gray-600 mb-4">
                Enter your city/town name to find nearby {getOrganDisplayName(organType)} specialists
              </p>
            </div>
            
            <div className="space-y-3">
              <Label htmlFor="location-input">Your Location</Label>
              <div className="flex space-x-2">
                <Input
                  id="location-input"
                  placeholder="e.g., New York, London, Mumbai, Chicago..."
                  value={userLocationText}
                  onChange={(e) => setUserLocationText(e.target.value)}
                  className="flex-1"
                  onKeyPress={(e) => {
                    if (e.key === 'Enter' && userLocationText.trim()) {
                      findHospitalsByLocation(userLocationText);
                    }
                  }}
                />
                <Button 
                  onClick={() => findHospitalsByLocation(userLocationText)} 
                  className="bg-blue-600 hover:bg-blue-700"
                  disabled={!userLocationText.trim() || loading}
                >
                  🔍 Find Hospitals
                </Button>
              </div>
            </div>
            
            {error && (
              <Alert>
                <AlertDescription className="text-red-600">
                  {error}
                </AlertDescription>
              </Alert>
            )}
          </div>
        )}

        {loading && (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">Searching for hospitals in {userLocationText}...</p>
            <p className="text-sm text-gray-500 mt-2">
              Finding {getOrganDisplayName(organType)} specialists near you
            </p>
          </div>
        )}



        {hospitals.length > 0 && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">
                {getOrganDisplayName(organType)} Specialists in {userLocationText}
              </h3>
              <Badge variant="outline">
                {hospitals.length} found
              </Badge>
            </div>

            <div className="space-y-3">
              {hospitals.map((hospital) => (
                <div key={hospital.id} className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h4 className="font-medium text-lg">{hospital.name}</h4>
                      <p className="text-sm text-blue-600">{hospital.speciality}</p>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center space-x-1">
                        <span className="text-yellow-500">⭐</span>
                        <span className="font-medium">{hospital.rating}</span>
                      </div>
                      <Badge 
                        variant={hospital.isOpen ? "default" : "secondary"}
                        className={hospital.isOpen ? "bg-green-100 text-green-800" : ""}
                      >
                        {hospital.isOpen ? 'Open' : 'Closed'}
                      </Badge>
                    </div>
                  </div>

                  <p className="text-sm text-gray-600 mb-2">{hospital.address}</p>
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="font-medium text-gray-600">Distance:</span>
                      <span className="ml-1 text-blue-600">{hospital.distance} km</span>
                    </div>
                    <div>
                      <span className="font-medium text-gray-600">Hours:</span>
                      <span className="ml-1">{hospital.openingHours}</span>
                    </div>
                  </div>

                  <Separator className="my-3" />

                  <div className="flex flex-wrap gap-2">
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => window.open(`tel:${hospital.phone}`, '_self')}
                    >
                      📞 Call
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => window.open(`https://maps.google.com/?q=${hospital.address}`, '_blank')}
                    >
                      🗺️ Directions
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => window.open(`https://${hospital.website}`, '_blank')}
                    >
                      🌐 Website
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-sm text-blue-800">
                <strong>Note:</strong> This feature requires Google Maps API integration for real-time data. 
                Current results are simulated for demonstration purposes.
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
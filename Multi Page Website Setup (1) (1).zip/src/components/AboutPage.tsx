import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';

export function AboutPage() {
  const teamMembers = [
    {
      name: 'Dr. Sarah Johnson',
      role: 'Chief Medical Officer',
      description: 'Board-certified physician with 15+ years of experience in diagnostic medicine.',
      avatar: '👩‍⚕️'
    },
    {
      name: 'Michael Chen',
      role: 'AI Research Lead',
      description: 'PhD in Machine Learning with expertise in medical AI applications.',
      avatar: '👨‍💻'
    },
    {
      name: 'Dr. Emma Rodriguez',
      role: 'Clinical Consultant',
      description: 'Emergency medicine specialist ensuring clinical accuracy of our algorithms.',
      avatar: '👩‍⚕️'
    }
  ];

  const features = [
    {
      title: 'Advanced Machine Learning',
      description: 'Our AI models are trained on vast medical datasets and continuously updated with the latest research.',
      icon: '🧠'
    },
    {
      title: 'Medical Expert Validation',
      description: 'All predictions are validated by licensed medical professionals to ensure accuracy.',
      icon: '✅'
    },
    {
      title: 'Privacy & Security',
      description: 'Your health data is encrypted and never shared with third parties.',
      icon: '🔐'
    },
    {
      title: '24/7 Availability',
      description: 'Get instant health insights anytime, anywhere with our online platform.',
      icon: '🕒'
    }
  ];

  return (
    <div className="min-h-screen bg-white py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">About Our Platform</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Empowering individuals with AI-driven health insights to make informed decisions about their wellbeing.
          </p>
        </div>

        {/* Mission Section */}
        <section className="mb-16">
          <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-0">
            <CardContent className="p-8">
              <div className="text-center">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Mission</h2>
                <p className="text-lg text-gray-700 max-w-4xl mx-auto leading-relaxed">
                  We believe everyone deserves access to reliable health information. Our AI-powered symptom checker 
                  combines cutting-edge technology with medical expertise to provide accurate, accessible healthcare 
                  guidance. We're bridging the gap between patients and healthcare providers, making preliminary 
                  health assessment available to everyone, everywhere.
                </p>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Features Section */}
        <section className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Trust Our Technology?</h2>
            <p className="text-lg text-gray-600">
              Built with the highest standards of medical accuracy and user privacy
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <span className="text-3xl">{feature.icon}</span>
                    <CardTitle className="text-xl">{feature.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-600 text-base">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Team Section */}
        <section className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Meet Our Expert Team</h2>
            <p className="text-lg text-gray-600">
              Medical professionals and technology experts working together
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {teamMembers.map((member, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="text-5xl mb-4">{member.avatar}</div>
                  <CardTitle className="text-xl">{member.name}</CardTitle>
                  <CardDescription className="text-blue-600 font-medium">
                    {member.role}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{member.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* How It Works */}
        <section className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">How It Works</h2>
            <p className="text-lg text-gray-600">
              Simple, fast, and accurate symptom analysis in three steps
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-blue-600">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Describe Symptoms</h3>
              <p className="text-gray-600">
                Enter your symptoms, their duration, and severity using our intuitive interface.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-blue-600">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">AI Analysis</h3>
              <p className="text-gray-600">
                Our advanced AI algorithms analyze your symptoms against medical databases.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-blue-600">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Get Insights</h3>
              <p className="text-gray-600">
                Receive possible conditions, recommendations, and guidance on next steps.
              </p>
            </div>
          </div>
        </section>

        {/* Disclaimer */}
        <section className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-yellow-800 mb-2">Important Medical Disclaimer</h3>
          <p className="text-yellow-700 text-sm leading-relaxed">
            This platform is designed to provide general health information and should not be used as a substitute 
            for professional medical advice, diagnosis, or treatment. Always consult with qualified healthcare 
            providers for medical concerns. In case of medical emergencies, contact emergency services immediately. 
            The information provided by our AI system is for educational purposes only and should not be considered 
            as medical advice.
          </p>
        </section>
      </div>
    </div>
  );
}
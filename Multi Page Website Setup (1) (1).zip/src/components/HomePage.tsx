import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface HomePageProps {
  onPageChange: (page: string) => void;
}

export function HomePage({ onPageChange }: HomePageProps) {
  const features = [
    {
      title: 'AI-Powered Analysis',
      description: 'Advanced algorithms analyze your symptoms to provide accurate predictions',
      icon: '🤖'
    },
    {
      title: 'Comprehensive Database',
      description: 'Access to thousands of medical conditions and their symptoms',
      icon: '📊'
    },
    {
      title: 'Quick Results',
      description: 'Get instant analysis and recommendations in seconds',
      icon: '⚡'
    },
    {
      title: 'Privacy First',
      description: 'Your health data remains private and secure',
      icon: '🔒'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      {/* Hero Section */}
      <section className="relative px-4 py-16 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 sm:text-5xl md:text-6xl">
              Your Health, <span className="text-blue-600">Analyzed</span>
            </h1>
            <p className="mt-6 max-w-2xl mx-auto text-xl text-gray-600">
              Get instant insights into your symptoms with our AI-powered disease prediction system. 
              Take control of your health with intelligent analysis.
            </p>
            <div className="mt-10 flex justify-center space-x-4">
              <Button 
                onClick={() => onPageChange('symptom-checker')}
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg text-lg"
              >
                Start Symptom Check
              </Button>
              <Button 
                variant="outline"
                onClick={() => onPageChange('about')}
                className="px-8 py-3 rounded-lg text-lg"
              >
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Why Choose Our Platform?</h2>
            <p className="mt-4 text-lg text-gray-600">
              Advanced technology meets healthcare expertise
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="text-4xl mb-4">{feature.icon}</div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-600">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-600 py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-white">
            Ready to Understand Your Symptoms?
          </h2>
          <p className="mt-4 text-xl text-blue-100">
            Take the first step towards better health awareness
          </p>
          <Button 
            onClick={() => onPageChange('symptom-checker')}
            className="mt-8 bg-white text-blue-600 hover:bg-gray-100 px-8 py-3 rounded-lg text-lg"
          >
            Get Started Now
          </Button>
        </div>
      </section>
    </div>
  );
}
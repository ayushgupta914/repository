import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Separator } from './ui/separator';
import { MLPredictionService } from './MLPredictionService';
import { HospitalLocator } from './HospitalLocator';

export function SymptomCheckerPage({ user, onSavePrediction } = {}) {
  const [duration, setDuration] = useState('');
  const [severity, setSeverity] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState('');
  const [additionalInfo, setAdditionalInfo] = useState('');
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [selectedOrgan, setSelectedOrgan] = useState('');
  const [predictionSaved, setPredictionSaved] = useState(false);

  // Comprehensive symptom data for each organ system
  const organSystems = {
    ear: {
      name: 'Ear',
      icon: '👂',
      symptoms: [
        'Ear pain (otalgia)',
        'Hearing loss (partial)',
        'Hearing loss (complete)',
        'Tinnitus (ringing)',
        'Tinnitus (buzzing)',
        'Tinnitus (hissing)',
        'Ear discharge (clear)',
        'Ear discharge (bloody)',
        'Ear discharge (pus-like)',
        'Ear discharge (thick/sticky)',
        'Dizziness/vertigo',
        'Spinning sensation',
        'Itching in ear canal',
        'Feeling of fullness/blockage',
        'Ear popping/crackling sounds',
        'Balance problems/unsteadiness',
        'Muffled hearing',
        'Sensitivity to loud sounds (hyperacusis)',
        'Ear pressure/discomfort',
        'Throbbing ear pain',
        'Sharp shooting ear pain',
        'Burning sensation in ear',
        'Swelling around ear',
        'Fever with ear symptoms',
        'Headache with ear pain',
        'Jaw pain near ear',
        'Difficulty hearing conversations',
        'Hearing echoes',
        'Sudden hearing loss',
        'Gradual hearing loss',
        'Nausea with ear symptoms',
        'Vomiting with dizziness',
        'Ear feels hot/warm',
        'Ear canal feels blocked',
        'Difficulty with phone conversations',
        'Need to turn up TV volume',
        'Asking people to repeat words',
        'Difficulty hearing in noisy places',
        'Ringing gets worse with noise',
        'Ear pain when chewing',
        'Ear pain when yawning',
        'Ear pain when swallowing',
        'Pulling/tugging at ear',
        'Ear feels wet inside',
        'Decreased hearing after swimming',
        'Ear canal looks red',
        'Visible ear wax buildup',
        'Ear drainage with bad smell',
        'Hearing own voice too loudly',
        'Sounds seem distorted'
      ],
      diseases: [
        { name: 'Otitis Media (Middle Ear Infection)', symptoms: ['throbbing ear pain', 'hearing loss (partial)', 'ear discharge (pus-like)', 'fever with ear symptoms', 'feeling of fullness/blockage', 'balance problems/unsteadiness'], severity: 'moderate' },
        { name: 'Otitis Externa (Swimmers Ear)', symptoms: ['sharp shooting ear pain', 'itching in ear canal', 'ear discharge (clear)', 'swelling around ear', 'ear canal looks red', 'decreased hearing after swimming'], severity: 'mild' },
        { name: 'Earwax Blockage', symptoms: ['muffled hearing', 'feeling of fullness/blockage', 'ear pressure/discomfort', 'tinnitus (buzzing)', 'visible ear wax buildup', 'ear canal feels blocked'], severity: 'mild' },
        { name: 'Acute Tinnitus', symptoms: ['tinnitus (ringing)', 'tinnitus (buzzing)', 'hearing loss (partial)', 'dizziness/vertigo', 'hearing own voice too loudly'], severity: 'mild' },
        { name: 'Chronic Tinnitus', symptoms: ['tinnitus (hissing)', 'gradual hearing loss', 'ringing gets worse with noise', 'sounds seem distorted'], severity: 'moderate' },
        { name: 'Menieres Disease', symptoms: ['spinning sensation', 'tinnitus (buzzing)', 'hearing loss (partial)', 'feeling of fullness/blockage', 'nausea with ear symptoms', 'vomiting with dizziness'], severity: 'moderate' },
        { name: 'Perforated Eardrum', symptoms: ['sharp shooting ear pain', 'hearing loss (partial)', 'ear discharge (bloody)', 'tinnitus (ringing)', 'dizziness/vertigo', 'ear feels wet inside'], severity: 'severe' },
        { name: 'Acoustic Neuroma', symptoms: ['gradual hearing loss', 'tinnitus (hissing)', 'balance problems/unsteadiness', 'dizziness/vertigo', 'difficulty hearing conversations'], severity: 'severe' },
        { name: 'TMJ Disorder', symptoms: ['ear pain when chewing', 'ear pain when yawning', 'jaw pain near ear', 'ear popping/crackling sounds', 'headache with ear pain'], severity: 'mild' },
        { name: 'Barotrauma', symptoms: ['ear pressure/discomfort', 'sharp shooting ear pain', 'muffled hearing', 'feeling of fullness/blockage', 'ear popping/crackling sounds'], severity: 'mild' },
        { name: 'Presbycusis', symptoms: ['gradual hearing loss', 'difficulty hearing conversations', 'need to turn up TV volume', 'asking people to repeat words', 'difficulty hearing in noisy places'], severity: 'mild' },
        { name: 'Noise-Induced Hearing Loss', symptoms: ['hearing loss (partial)', 'tinnitus (ringing)', 'sensitivity to loud sounds (hyperacusis)', 'muffled hearing', 'difficulty with phone conversations'], severity: 'moderate' },
        { name: 'Labyrinthitis', symptoms: ['spinning sensation', 'balance problems/unsteadiness', 'nausea with ear symptoms', 'vomiting with dizziness', 'hearing loss (partial)'], severity: 'moderate' },
        { name: 'Mastoiditis', symptoms: ['throbbing ear pain', 'fever with ear symptoms', 'swelling around ear', 'headache with ear pain', 'ear discharge (pus-like)'], severity: 'severe' },
        { name: 'Otosclerosis', symptoms: ['gradual hearing loss', 'tinnitus (buzzing)', 'hearing own voice too loudly', 'difficulty hearing conversations'], severity: 'moderate' }
      ]
    },
    eyes: {
      name: 'Eyes',
      icon: '👁️',
      symptoms: [
        'Eye pain (sharp)',
        'Eye pain (dull ache)',
        'Eye pain (throbbing)',
        'Blurred vision (near)',
        'Blurred vision (distance)',
        'Blurred vision (both)',
        'Double vision (diplopia)',
        'Dry eyes/insufficient tears',
        'Excessive tearing/watery eyes',
        'Red eyes (bloodshot)',
        'Red eyes (pink/irritated)',
        'Itchy eyes',
        'Burning eyes',
        'Stinging sensation',
        'Light sensitivity (photophobia)',
        'Night blindness',
        'Eye discharge (clear)',
        'Eye discharge (yellow/green)',
        'Eye discharge (sticky/crusty)',
        'Swollen eyelids',
        'Drooping eyelids (ptosis)',
        'Twitching eyelids',
        'Puffy eyes',
        'Dark circles under eyes',
        'Floaters in vision',
        'Flashing lights in vision',
        'Sparkles/stars in vision',
        'Loss of peripheral vision',
        'Loss of central vision',
        'Blind spots in vision',
        'Tunnel vision',
        'Foreign body sensation',
        'Gritty feeling in eyes',
        'Sandy feeling in eyes',
        'Eyes feel heavy',
        'Difficulty opening eyes',
        'Difficulty closing eyes completely',
        'Eye strain/fatigue',
        'Headache with eye symptoms',
        'Nausea with vision changes',
        'Dizziness with vision problems',
        'Seeing halos around lights',
        'Glare sensitivity',
        'Difficulty seeing at dusk',
        'Colors appear faded',
        'Difficulty reading small print',
        'Need brighter light to read',
        'Squinting frequently',
        'Rubbing eyes often',
        'Tearing in wind/cold',
        'Eyes feel tired after reading',
        'Computer eye strain',
        'Contact lens discomfort',
        'Eyelashes falling out',
        'Eyelid inflammation',
        'Stye/bump on eyelid',
        'Chalazion/cyst on eyelid',
        'Sudden vision loss',
        'Gradual vision loss',
        'Curtain-like vision loss',
        'Wavy lines in vision',
        'Distorted vision',
        'Objects appear smaller/larger',
        'Difficulty judging distances',
        'Bumping into objects',
        'Trouble with stairs',
        'Eye pressure sensation',
        'Eyes feel bulging',
        'Unequal pupil sizes',
        'Pupils do not react to light',
        'Cross-eyed appearance',
        'Eyes do not move together',
        'Flickering vision',
        'Vision blackouts',
        'Temporary vision loss'
      ],
      diseases: [
        { name: 'Bacterial Conjunctivitis', symptoms: ['red eyes (bloodshot)', 'eye discharge (yellow/green)', 'eye discharge (sticky/crusty)', 'burning eyes', 'foreign body sensation', 'difficulty opening eyes'], severity: 'mild' },
        { name: 'Dry Eye Syndrome', symptoms: ['dry eyes/insufficient tears', 'burning eyes', 'stinging sensation', 'gritty feeling in eyes', 'sandy feeling in eyes', 'blurred vision (both)', 'eye strain/fatigue'], severity: 'mild' },
        { name: 'Glaucoma', symptoms: ['eye pain', 'blurred vision', 'loss of peripheral vision', 'light sensitivity'], severity: 'severe' },
        { name: 'Cataracts', symptoms: ['blurred vision', 'light sensitivity', 'night blindness', 'double vision'], severity: 'moderate' },
        { name: 'Stye/Chalazion', symptoms: ['swollen eyelids', 'eye pain', 'red eyes'], severity: 'mild' },
        { name: 'Allergic Conjunctivitis', symptoms: ['itchy eyes', 'watery eyes', 'red eyes', 'swollen eyelids'], severity: 'mild' },
        { name: 'Retinal Detachment', symptoms: ['floaters', 'flashing lights', 'loss of peripheral vision', 'blurred vision'], severity: 'severe' },
        { name: 'Macular Degeneration', symptoms: ['blurred vision (near)', 'loss of central vision', 'difficulty reading small print', 'wavy lines in vision', 'distorted vision', 'objects appear smaller/larger'], severity: 'severe' },
        { name: 'Viral Conjunctivitis', symptoms: ['red eyes (pink/irritated)', 'excessive tearing/watery eyes', 'eye discharge (clear)', 'itchy eyes', 'light sensitivity (photophobia)'], severity: 'mild' },
        { name: 'Acute Glaucoma', symptoms: ['eye pain (sharp)', 'blurred vision (both)', 'seeing halos around lights', 'nausea with vision changes', 'headache with eye symptoms'], severity: 'severe' },
        { name: 'Chronic Glaucoma', symptoms: ['loss of peripheral vision', 'tunnel vision', 'gradual vision loss', 'difficulty seeing at dusk'], severity: 'severe' },
        { name: 'Stye (Hordeolum)', symptoms: ['stye/bump on eyelid', 'eye pain (dull ache)', 'swollen eyelids', 'red eyes (bloodshot)', 'tearing in wind/cold'], severity: 'mild' },
        { name: 'Chalazion', symptoms: ['chalazion/cyst on eyelid', 'swollen eyelids', 'eyes feel heavy', 'blurred vision (near)', 'difficulty closing eyes completely'], severity: 'mild' },
        { name: 'Diabetic Retinopathy', symptoms: ['floaters in vision', 'blurred vision (both)', 'dark circles under eyes', 'difficulty seeing at dusk', 'vision blackouts'], severity: 'severe' },
        { name: 'Ptosis', symptoms: ['drooping eyelids (ptosis)', 'difficulty opening eyes', 'eyes feel heavy', 'eye strain/fatigue', 'headache with eye symptoms'], severity: 'moderate' },
        { name: 'Blepharitis', symptoms: ['burning eyes', 'itchy eyes', 'red eyes (pink/irritated)', 'eye discharge (sticky/crusty)', 'eyelid inflammation', 'eyelashes falling out'], severity: 'mild' },
        { name: 'Uveitis', symptoms: ['eye pain (sharp)', 'light sensitivity (photophobia)', 'red eyes (bloodshot)', 'blurred vision (both)', 'floaters in vision'], severity: 'moderate' },
        { name: 'Corneal Abrasion', symptoms: ['eye pain (sharp)', 'foreign body sensation', 'excessive tearing/watery eyes', 'light sensitivity (photophobia)', 'difficulty opening eyes'], severity: 'moderate' },
        { name: 'Computer Vision Syndrome', symptoms: ['eye strain/fatigue', 'dry eyes/insufficient tears', 'blurred vision (near)', 'headache with eye symptoms', 'computer eye strain'], severity: 'mild' }
      ]
    },
    lungs: {
      name: 'Lungs',
      icon: '🫁',
      symptoms: [
        'Dry cough (hacking)',
        'Dry cough (persistent)',
        'Productive cough (with phlegm)',
        'Productive cough (thick mucus)',
        'Productive cough (colored sputum)',
        'Cough with blood (hemoptysis)',
        'Cough worse at night',
        'Cough worse in morning',
        'Chronic cough (over 8 weeks)',
        'Acute cough (under 3 weeks)',
        'Shortness of breath at rest',
        'Shortness of breath with activity',
        'Shortness of breath when lying down',
        'Sudden shortness of breath',
        'Gradual shortness of breath',
        'Chest pain (sharp)',
        'Chest pain (dull ache)',
        'Chest pain (stabbing)',
        'Chest pain (burning)',
        'Chest pain with breathing',
        'Chest pain with coughing',
        'Wheezing (high-pitched)',
        'Wheezing (low-pitched)',
        'Wheezing with breathing in',
        'Wheezing with breathing out',
        'Chest tightness/constriction',
        'Chest heaviness',
        'Difficulty taking deep breaths',
        'Cannot catch breath',
        'Rapid breathing (tachypnea)',
        'Shallow breathing',
        'Irregular breathing',
        'Labored breathing',
        'Breathing through mouth',
        'Using accessory muscles to breathe',
        'Fatigue/exhaustion',
        'Extreme tiredness',
        'Weakness',
        'Low energy levels',
        'Fever (low-grade)',
        'Fever (high-grade)',
        'Chills with fever',
        'Sweating with fever',
        'Clear sputum production',
        'White/gray sputum',
        'Yellow sputum',
        'Green sputum',
        'Brown sputum',
        'Pink/frothy sputum',
        'Rust-colored sputum',
        'Thick sticky mucus',
        'Difficulty coughing up mucus',
        'Night sweats',
        'Excessive sweating',
        'Weight loss (unintentional)',
        'Loss of appetite',
        'Hoarse voice with cough',
        'Voice changes',
        'Throat irritation',
        'Sore throat with cough',
        'Runny nose with cough',
        'Nasal congestion',
        'Post-nasal drip',
        'Sneezing with respiratory symptoms',
        'Headache with respiratory symptoms',
        'Body aches',
        'Muscle pain',
        'Joint pain with respiratory illness',
        'Blue lips/fingernails (cyanosis)',
        'Pale skin',
        'Dizziness with breathing problems',
        'Lightheadedness',
        'Anxiety about breathing',
        'Panic with shortness of breath',
        'Sleep problems due to cough',
        'Waking up gasping for air',
        'Snoring with breathing issues',
        'Sleep apnea symptoms',
        'Difficulty exercising',
        'Exercise intolerance',
        'Leg swelling with breathing problems',
        'Heart palpitations with breathing issues',
        'Barrel chest appearance',
        'Using pillows to sleep upright',
        'Morning cough with sputum',
        'Seasonal cough symptoms',
        'Cough triggered by cold air',
        'Cough triggered by exercise',
        'Cough triggered by laughing',
        'Cough triggered by strong odors',
        'Allergic cough symptoms',
        'Smoking-related cough',
        'Occupational cough',
        'Medication-induced cough',
        'GERD-related cough',
        'Chronic bronchitis symptoms',
        'Emphysema symptoms',
        'Asthma-like symptoms',
        'Pneumonia-like symptoms'
      ],
      diseases: [
        { name: 'Asthma', symptoms: ['wheezing (high-pitched)', 'shortness of breath with activity', 'chest tightness/constriction', 'dry cough (persistent)', 'cough worse at night', 'difficulty taking deep breaths'], severity: 'moderate' },
        { name: 'Acute Bronchitis', symptoms: ['productive cough (with phlegm)', 'chest pain (dull ache)', 'fatigue/exhaustion', 'fever (low-grade)', 'cough worse in morning', 'yellow sputum'], severity: 'mild' },
        { name: 'Pneumonia', symptoms: ['productive cough', 'fever', 'chest pain', 'shortness of breath'], severity: 'severe' },
        { name: 'COPD', symptoms: ['shortness of breath', 'productive cough', 'wheezing', 'chest tightness'], severity: 'severe' },
        { name: 'Common Cold', symptoms: ['dry cough', 'fatigue', 'chest tightness'], severity: 'mild' },
        { name: 'Upper Respiratory Infection', symptoms: ['dry cough', 'chest pain', 'fatigue', 'fever'], severity: 'mild' },
        { name: 'Pulmonary Embolism', symptoms: ['shortness of breath', 'chest pain', 'rapid breathing', 'blood in sputum'], severity: 'severe' },
        { name: 'Lung Cancer', symptoms: ['chronic cough (over 8 weeks)', 'cough with blood (hemoptysis)', 'weight loss (unintentional)', 'chest pain (stabbing)', 'shortness of breath at rest', 'hoarse voice with cough'], severity: 'severe' },
        { name: 'Chronic Bronchitis', symptoms: ['productive cough (thick mucus)', 'morning cough with sputum', 'shortness of breath with activity', 'wheezing (low-pitched)', 'chronic bronchitis symptoms'], severity: 'moderate' },
        { name: 'Emphysema', symptoms: ['shortness of breath at rest', 'barrel chest appearance', 'difficulty exercising', 'emphysema symptoms', 'using accessory muscles to breathe'], severity: 'severe' },
        { name: 'Pneumothorax', symptoms: ['sudden shortness of breath', 'chest pain (sharp)', 'chest pain with breathing', 'rapid breathing (tachypnea)', 'anxiety about breathing'], severity: 'severe' },
        { name: 'Pleuritis', symptoms: ['chest pain (sharp)', 'chest pain with breathing', 'chest pain with coughing', 'shallow breathing', 'difficulty taking deep breaths'], severity: 'moderate' },
        { name: 'Whooping Cough', symptoms: ['dry cough (hacking)', 'cough triggered by laughing', 'difficulty catching breath', 'fever (low-grade)', 'exhaustion after coughing'], severity: 'moderate' },
        { name: 'Tuberculosis', symptoms: ['chronic cough (over 8 weeks)', 'cough with blood (hemoptysis)', 'night sweats', 'weight loss (unintentional)', 'fever (low-grade)', 'chest pain (dull ache)'], severity: 'severe' },
        { name: 'Allergic Asthma', symptoms: ['wheezing with breathing out', 'seasonal cough symptoms', 'cough triggered by strong odors', 'allergic cough symptoms', 'shortness of breath with activity'], severity: 'moderate' },
        { name: 'Exercise-Induced Asthma', symptoms: ['cough triggered by exercise', 'shortness of breath with activity', 'wheezing (high-pitched)', 'chest tightness/constriction', 'difficulty exercising'], severity: 'mild' },
        { name: 'Sleep Apnea', symptoms: ['sleep problems due to cough', 'waking up gasping for air', 'snoring with breathing issues', 'sleep apnea symptoms', 'fatigue/exhaustion'], severity: 'moderate' },
        { name: 'GERD-Related Cough', symptoms: ['GERD-related cough', 'dry cough (persistent)', 'cough worse at night', 'throat irritation', 'hoarse voice with cough'], severity: 'mild' },
        { name: 'Occupational Lung Disease', symptoms: ['occupational cough', 'chronic cough (over 8 weeks)', 'shortness of breath with activity', 'chest tightness/constriction'], severity: 'moderate' },
        { name: 'Viral Pneumonia', symptoms: ['dry cough (persistent)', 'fever (high-grade)', 'fatigue/exhaustion', 'body aches', 'headache with respiratory symptoms'], severity: 'moderate' },
        { name: 'Bacterial Pneumonia', symptoms: ['productive cough (colored sputum)', 'rust-colored sputum', 'fever (high-grade)', 'chills with fever', 'chest pain with breathing'], severity: 'severe' }
      ]
    }
  };

  const [selectedSymptoms, setSelectedSymptoms] = useState([]);

  const handleSymptomToggle = (symptom) => {
    setSelectedSymptoms(prev => 
      prev.includes(symptom) 
        ? prev.filter(s => s !== symptom)
        : [...prev, symptom]
    );
  };



  const analyzeSymptoms = async () => {
    if (!selectedOrgan || selectedSymptoms.length === 0) {
      return;
    }

    setLoading(true);
    
    // Simulate ML processing time
    setTimeout(() => {
      const organData = organSystems[selectedOrgan];
      
      // Convert age to age group
      const ageNum = parseInt(age) || 25;
      const ageGroup = ageNum < 18 ? 'child' : ageNum < 65 ? 'adult' : 'elderly';
      
      // Prepare symptom data for ML models
      const symptomData = {
        organ: organData.name,
        symptoms: selectedSymptoms,
        duration: duration,
        severity: severity,
        age: ageGroup,
        gender: gender,
        additionalInfo: additionalInfo
      };

      // Get ML predictions from ensemble of three models
      const mlPredictions = MLPredictionService.predict(symptomData);
      
      // Convert ML predictions to UI format
      const possibleConditions = mlPredictions.map(prediction => ({
        name: prediction.condition,
        probability: prediction.probability,
        confidence: prediction.confidence,
        description: `AI-diagnosed condition affecting the ${organData.name.toLowerCase()}`,
        severity: prediction.severity,
        matchedSymptoms: selectedSymptoms.length,
        totalSymptoms: selectedSymptoms.length,
        modelScores: prediction.modelScores
      }));

      // Generate ML-based recommendations
      const topPrediction = mlPredictions[0];
      const recommendations = topPrediction 
        ? MLPredictionService.generateRecommendations(topPrediction, symptomData)
        : [
            'Consider consulting a healthcare provider for further evaluation',
            'Monitor symptoms closely for any changes',
            'Keep a detailed symptom diary'
          ];

      const urgency = possibleConditions.some(d => d.severity === 'severe') || severity === 'severe' ? 'high' : 'low';

      const mlResults = {
        organ: organData.name,
        possibleConditions: possibleConditions.slice(0, 5), // Top 5 ML predictions
        recommendations,
        severity,
        urgency,
        selectedSymptoms: selectedSymptoms.length,
        analysisDate: new Date().toLocaleDateString(),
        mlAnalysis: {
          modelsUsed: ['Logistic Regression', 'Random Forest', 'Gradient Boosting'],
          ensembleMethod: 'Weighted Average',
          topPrediction: topPrediction || null
        }
      };
      
      // Save prediction if user is logged in - only the highest confidence disease
      let saved = false;
      if (user && onSavePrediction && possibleConditions.length > 0) {
        const topCondition = possibleConditions[0];
        const predictionData = {
          organ: organData.name,
          symptoms: selectedSymptoms,
          topCondition: topCondition.name,
          probability: topCondition.probability,
          severity: topCondition.severity,
          recommendations,
          status: topCondition.severity === 'severe' ? 'urgent' : 
                 topCondition.severity === 'moderate' ? 'monitoring' : 'pending',
          // Include ML model scores for the top condition
          modelScores: topCondition.modelScores
        };
        saved = await onSavePrediction(predictionData);
      }
      
      setPredictionSaved(saved);
      setResults(mlResults);
      setLoading(false);
    }, 3500); // Slightly longer to simulate complex ML processing
  };

  const resetForm = () => {
    setDuration('');
    setSeverity('');
    setAge('');
    setGender('');
    setAdditionalInfo('');
    setSelectedSymptoms([]);
    setSelectedOrgan('');
    setResults(null);
    setPredictionSaved(false);
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'severe': return 'bg-red-100 text-red-800';
      case 'moderate': return 'bg-yellow-100 text-yellow-800';
      case 'mild': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">AI Symptom Checker</h1>
          <p className="text-xl text-gray-600">
            Get instant AI-powered health insights by describing your symptoms
          </p>
          <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg inline-block">
            <p className="text-sm text-blue-800">
              🧠 Powered by Advanced Machine Learning: Logistic Regression + Random Forest + Gradient Boosting
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Input Form */}
          <Card>
            <CardHeader>
              <CardTitle>Describe Your Symptoms</CardTitle>
              <CardDescription>
                Select your affected organ system and symptoms for AI analysis
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Organ Selection */}
              <div>
                <Label>Affected Organ System</Label>
                <Tabs value={selectedOrgan} onValueChange={setSelectedOrgan} className="mt-2">
                  <TabsList className="grid w-full grid-cols-3">
                    {Object.entries(organSystems).map(([key, organ]) => (
                      <TabsTrigger key={key} value={key} className="flex items-center space-x-2">
                        <span>{organ.icon}</span>
                        <span>{organ.name}</span>
                      </TabsTrigger>
                    ))}
                  </TabsList>
                </Tabs>
              </div>

              {/* Symptom Selection */}
              {selectedOrgan && (
                <div>
                  <Label>Select Your Symptoms ({selectedSymptoms.length} selected)</Label>
                  <div className="mt-2 max-h-80 overflow-y-auto border border-gray-200 rounded-md p-4 bg-gray-50">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {organSystems[selectedOrgan].symptoms.map((symptom, index) => (
                        <div key={index} className="flex items-center space-x-3 p-2 bg-white rounded border hover:bg-blue-50 transition-colors">
                          <Checkbox
                            id={`symptom-${index}`}
                            checked={selectedSymptoms.includes(symptom)}
                            onCheckedChange={() => handleSymptomToggle(symptom)}
                          />
                          <Label htmlFor={`symptom-${index}`} className="text-sm cursor-pointer flex-1 leading-relaxed">
                            {symptom}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                  {selectedSymptoms.length > 0 && (
                    <div className="mt-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                      <p className="text-sm text-blue-800 font-medium">
                        ✓ {selectedSymptoms.length} symptoms selected for analysis
                      </p>
                      <div className="mt-2 flex flex-wrap gap-1">
                        {selectedSymptoms.slice(0, 5).map((symptom, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {symptom.length > 20 ? symptom.substring(0, 20) + '...' : symptom}
                          </Badge>
                        ))}
                        {selectedSymptoms.length > 5 && (
                          <Badge variant="outline" className="text-xs">
                            +{selectedSymptoms.length - 5} more
                          </Badge>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Duration */}
              <div>
                <Label htmlFor="duration">How long have you had these symptoms?</Label>
                <Select value={duration} onValueChange={setDuration}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select duration" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hours">A few hours</SelectItem>
                    <SelectItem value="days">1-3 days</SelectItem>
                    <SelectItem value="week">About a week</SelectItem>
                    <SelectItem value="weeks">2-4 weeks</SelectItem>
                    <SelectItem value="months">More than a month</SelectItem>
                    <SelectItem value="chronic">Chronic (ongoing)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Severity */}
              <div>
                <Label>Symptom Severity</Label>
                <Select value={severity} onValueChange={setSeverity}>
                  <SelectTrigger>
                    <SelectValue placeholder="How severe are your symptoms?" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mild">Mild - Doesn't interfere with daily activities</SelectItem>
                    <SelectItem value="moderate">Moderate - Some interference with activities</SelectItem>
                    <SelectItem value="severe">Severe - Significantly impacts daily life</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Age and Gender */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="age">Age</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Your age"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="1"
                    max="120"
                  />
                </div>
                <div>
                  <Label>Gender</Label>
                  <Select value={gender} onValueChange={setGender}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                      <SelectItem value="prefer-not-to-say">Prefer not to say</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="additional-info">Additional Information</Label>
                <Textarea
                  id="additional-info"
                  placeholder="Any additional details about your symptoms, triggers, or concerns..."
                  value={additionalInfo}
                  onChange={(e) => setAdditionalInfo(e.target.value)}
                  rows={3}
                />
              </div>

              <div className="flex space-x-3">
                <Button 
                  onClick={analyzeSymptoms}
                  disabled={loading || !selectedOrgan || selectedSymptoms.length === 0}
                  className="flex-1"
                >
                  {loading ? 'Analyzing...' : 'Analyze Symptoms'}
                </Button>
                <Button variant="outline" onClick={resetForm}>
                  Reset
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Results */}
          <Card>
            <CardHeader>
              <CardTitle>Analysis Results</CardTitle>
              <CardDescription>
                AI-powered diagnosis suggestions based on your symptoms
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loading && (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
                  <p className="mt-4 text-gray-600">Processing with AI Models...</p>
                  <div className="mt-4 space-y-2 text-sm text-gray-500">
                    <p>🧠 Running Logistic Regression analysis...</p>
                    <p>🌳 Executing Random Forest predictions...</p>
                    <p>🚀 Computing Gradient Boosting results...</p>
                    <p>🔄 Combining ensemble predictions...</p>
                  </div>
                  <p className="mt-4 text-xs text-gray-400">
                    Analyzing {selectedSymptoms.length} symptoms against medical knowledge base
                  </p>
                </div>
              )}

              {results && (
                <div className="space-y-6">
                  {/* Analysis Summary */}
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold">Analysis Summary</h3>
                      <Badge variant="outline">{results.analysisDate}</Badge>
                    </div>
                    <p className="text-sm text-blue-800">
                      Analyzed {results.selectedSymptoms} symptoms for {results.organ} conditions
                    </p>
                  </div>

                  {/* Top Predicted Disease - Highest Confidence */}
                  <div className="p-6 bg-gradient-to-r from-blue-50 to-indigo-50 border-2 border-blue-300 rounded-lg shadow-md">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-blue-900 flex items-center">
                        <span className="mr-2">🏥</span>
                        Predicted Disease (Highest Confidence)
                      </h3>
                      {predictionSaved && user && (
                        <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">
                          ✓ Saved to Profile
                        </Badge>
                      )}
                    </div>
                    {results.possibleConditions.length > 0 ? (
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <h4 className="text-blue-900">
                            {results.possibleConditions[0].name}
                          </h4>
                          <Badge className={`${getSeverityColor(results.possibleConditions[0].severity)}`}>
                            {results.possibleConditions[0].severity.toUpperCase()}
                          </Badge>
                        </div>
                        
                        <div className="bg-white p-4 rounded-lg border border-blue-200">
                          <div className="grid grid-cols-2 gap-4 mb-3">
                            <div>
                              <span className="text-gray-600">Overall Confidence:</span>
                              <div className="mt-1">
                                <Progress value={results.possibleConditions[0].probability} className="h-2" />
                                <span className="text-blue-700 mt-1 block">
                                  {results.possibleConditions[0].probability}%
                                </span>
                              </div>
                            </div>
                            <div>
                              <span className="text-gray-600">Analysis Date:</span>
                              <p className="text-gray-900 mt-1">{results.analysisDate}</p>
                            </div>
                          </div>
                          
                          {/* ML Model Scores for Top Disease */}
                          {results.possibleConditions[0].modelScores && (
                            <div className="mt-3 pt-3 border-t border-gray-200">
                              <p className="text-gray-600 mb-2">ML Model Scores:</p>
                              <div className="grid grid-cols-3 gap-2">
                                <div className="bg-blue-50 p-2 rounded text-center">
                                  <div className="text-blue-700">Logistic Regression</div>
                                  <div className="text-blue-900">{results.possibleConditions[0].modelScores.logisticRegression}%</div>
                                </div>
                                <div className="bg-green-50 p-2 rounded text-center">
                                  <div className="text-green-700">Random Forest</div>
                                  <div className="text-green-900">{results.possibleConditions[0].modelScores.randomForest}%</div>
                                </div>
                                <div className="bg-purple-50 p-2 rounded text-center">
                                  <div className="text-purple-700">Gradient Boosting</div>
                                  <div className="text-purple-900">{results.possibleConditions[0].modelScores.gradientBoosting}%</div>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                        
                        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                          <p className="text-yellow-800">
                            <strong>Note:</strong> This is the condition with the highest confidence score based on your symptoms. 
                            Always consult a healthcare professional for proper diagnosis.
                          </p>
                        </div>
                      </div>
                    ) : (
                      <p className="text-blue-800">
                        No clear diagnosis found - consultation recommended
                      </p>
                    )}
                  </div>

                  <div>
                    <h3 className="font-semibold text-lg mb-3">Detailed AI Analysis</h3>
                    {results.possibleConditions.length > 0 ? (
                      <div className="space-y-4">
                        {/* ML Analysis Info */}
                        {results.mlAnalysis && (
                          <div className="p-3 bg-gray-50 border border-gray-200 rounded-lg">
                            <div className="flex items-center space-x-2 mb-2">
                              <span className="text-gray-600">🤖</span>
                              <span className="font-medium text-gray-800">ML Ensemble Analysis</span>
                            </div>
                            <p className="text-sm text-gray-700">
                              Models: {results.mlAnalysis.modelsUsed.join(', ')}
                            </p>
                            <p className="text-xs text-gray-600">
                              Method: {results.mlAnalysis.ensembleMethod}
                            </p>
                          </div>
                        )}
                        
                        {/* All Possible Conditions (for reference only) */}
                        <div className="space-y-3">
                          <h4 className="text-gray-700">Alternative Diagnoses (For Reference):</h4>
                          <p className="text-gray-600">
                            These are other possible conditions ranked by confidence. Only the top condition is saved to your profile.
                          </p>
                          {results.possibleConditions.map((condition, index) => (
                            <div key={index} className="p-3 border border-gray-200 rounded-lg">
                              <div className="flex justify-between items-start mb-2">
                                <div className="flex items-center space-x-2">
                                  <span className="text-gray-600">{index + 1}.</span>
                                  <h5 className="font-medium">{condition.name}</h5>
                                </div>
                                <div className="flex space-x-2">
                                  <Badge className={getSeverityColor(condition.severity)}>
                                    {condition.severity}
                                  </Badge>
                                  <span className={`px-2 py-1 rounded text-xs ${
                                    condition.probability > 80 ? 'bg-green-100 text-green-800' :
                                    condition.probability > 65 ? 'bg-yellow-100 text-yellow-800' :
                                    'bg-red-100 text-red-800'
                                  }`}>
                                    {condition.probability}%
                                  </span>
                                </div>
                              </div>
                              
                              {/* ML Model Scores */}
                              {condition.modelScores && (
                                <div className="mt-2">
                                  <div className="grid grid-cols-3 gap-2 text-xs">
                                    <div className="bg-gray-100 p-2 rounded">
                                      <div className="font-medium">LR</div>
                                      <div className="text-blue-600">{condition.modelScores.logisticRegression}%</div>
                                    </div>
                                    <div className="bg-gray-100 p-2 rounded">
                                      <div className="font-medium">RF</div>
                                      <div className="text-green-600">{condition.modelScores.randomForest}%</div>
                                    </div>
                                    <div className="bg-gray-100 p-2 rounded">
                                      <div className="font-medium">GB</div>
                                      <div className="text-purple-600">{condition.modelScores.gradientBoosting}%</div>
                                    </div>
                                  </div>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <p className="text-gray-600 italic">
                        No conditions identified. Please consult a healthcare provider for further evaluation.
                      </p>
                    )}
                  </div>

                  <div>
                    <h3 className="font-semibold text-lg mb-3">Recommendations</h3>
                    <ul className="space-y-2">
                      {results.recommendations.map((rec, index) => (
                        <li key={index} className="flex items-start">
                          <span className="text-blue-600 mr-2">•</span>
                          <span className="text-sm">{rec}</span>
                        </li>
                      ))}
                    </ul>
                  </div>



                  {/* User Profile Integration Status */}
                  {user && results.possibleConditions.length > 0 && (
                    <div className="p-4 border rounded-lg bg-green-50 border-green-200">
                      <div className="flex items-center text-green-800">
                        <span className="mr-2">✅</span>
                        <span className="font-medium">
                          Analysis complete! Prediction saved to your health profile.
                        </span>
                      </div>
                      <p className="text-sm text-green-700 mt-1">
                        Visit your dashboard to download detailed reports with nearby hospital information.
                      </p>
                    </div>
                  )}
                  
                  {!user && results.possibleConditions.length > 0 && (
                    <div className="p-4 border rounded-lg bg-blue-50 border-blue-200">
                      <div className="flex items-center text-blue-800">
                        <span className="mr-2">ℹ️</span>
                        <span className="font-medium">
                          Analysis complete! Sign in to save predictions and download detailed reports.
                        </span>
                      </div>
                      <p className="text-sm text-blue-700 mt-1">
                        Registered users can access downloadable reports with hospital information.
                      </p>
                    </div>
                  )}

                  <Separator />

                  {/* Disclaimer */}
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-2">Medical Disclaimer</h4>
                    <p className="text-sm text-red-700">
                      This AI tool provides informational insights only and should not replace professional medical advice, 
                      diagnosis, or treatment. Always consult with a qualified healthcare provider for proper medical evaluation.
                    </p>
                  </div>
                </div>
              )}

              {!results && !loading && (
                <div className="text-center py-8 text-gray-500">
                  <div className="text-4xl mb-4">🔍</div>
                  <p>Select an organ system and symptoms to get started with AI analysis</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Hospital Locator - Shows after analysis */}
        {results && selectedOrgan && (
          <div className="mt-8">
            <HospitalLocator organType={selectedOrgan} />
          </div>
        )}
      </div>
    </div>
  );
}
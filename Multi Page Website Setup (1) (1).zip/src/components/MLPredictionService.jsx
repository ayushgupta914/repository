// Machine Learning Prediction Service
// Simulates Logistic Regression, Random Forest, and Gradient Boosting models

export class MLPredictionService {
  // Medical knowledge base for each organ system
  static medicalKnowledge = {
    'Ear': {
      diseases: [
        {
          name: 'Otitis Media',
          symptoms: ['ear pain', 'hearing loss', 'fever', 'drainage', 'feeling of fullness'],
          severity: 'moderate',
          commonAge: ['child', 'adult'],
          riskFactors: ['cold', 'allergy', 'smoking']
        },
        {
          name: 'Earwax Blockage',
          symptoms: ['hearing loss', 'feeling of fullness', 'ear pain', 'tinnitus', 'dizziness'],
          severity: 'mild',
          commonAge: ['adult', 'elderly'],
          riskFactors: ['cotton swab use', 'narrow ear canal']
        },
        {
          name: 'Meniere\'s Disease',
          symptoms: ['dizziness', 'tinnitus', 'hearing loss', 'nausea', 'vertigo'],
          severity: 'moderate',
          commonAge: ['adult', 'elderly'],
          riskFactors: ['stress', 'salt intake', 'genetics']
        },
        {
          name: 'Acoustic Neuroma',
          symptoms: ['hearing loss', 'tinnitus', 'balance problems', 'facial numbness'],
          severity: 'severe',
          commonAge: ['adult', 'elderly'],
          riskFactors: ['genetics', 'radiation exposure']
        },
        {
          name: 'Otitis Externa',
          symptoms: ['ear pain', 'itching', 'discharge', 'hearing loss', 'swelling'],
          severity: 'mild',
          commonAge: ['adult', 'child'],
          riskFactors: ['swimming', 'humidity', 'injury']
        },
        {
          name: 'Tinnitus',
          symptoms: ['ringing', 'buzzing', 'hearing loss', 'concentration problems'],
          severity: 'mild',
          commonAge: ['adult', 'elderly'],
          riskFactors: ['noise exposure', 'medications', 'age']
        }
      ]
    },
    'Eyes': {
      diseases: [
        {
          name: 'Allergic Conjunctivitis',
          symptoms: ['red eyes', 'itchy eyes', 'watery eyes', 'swelling', 'discharge'],
          severity: 'mild',
          commonAge: ['child', 'adult'],
          riskFactors: ['allergies', 'pollen', 'dust']
        },
        {
          name: 'Dry Eye Syndrome',
          symptoms: ['blurred vision', 'eye pain', 'light sensitivity', 'burning', 'gritty feeling'],
          severity: 'moderate',
          commonAge: ['adult', 'elderly'],
          riskFactors: ['computer use', 'age', 'hormones']
        },
        {
          name: 'Cataracts',
          symptoms: ['blurred vision', 'night blindness', 'light sensitivity', 'halos', 'cloudy vision'],
          severity: 'moderate',
          commonAge: ['elderly'],
          riskFactors: ['age', 'diabetes', 'smoking']
        },
        {
          name: 'Glaucoma',
          symptoms: ['vision loss', 'eye pain', 'headache', 'nausea', 'tunnel vision'],
          severity: 'severe',
          commonAge: ['adult', 'elderly'],
          riskFactors: ['family history', 'age', 'high pressure']
        },
        {
          name: 'Macular Degeneration',
          symptoms: ['blurred vision', 'dark spots', 'difficulty reading', 'color changes'],
          severity: 'severe',
          commonAge: ['elderly'],
          riskFactors: ['age', 'smoking', 'genetics']
        },
        {
          name: 'Bacterial Conjunctivitis',
          symptoms: ['red eyes', 'discharge', 'crusting', 'eye pain', 'swelling'],
          severity: 'moderate',
          commonAge: ['child', 'adult'],
          riskFactors: ['infection', 'contact', 'poor hygiene']
        }
      ]
    },
    'Lungs': {
      diseases: [
        {
          name: 'Asthma',
          symptoms: ['wheezing', 'shortness of breath', 'chest tightness', 'dry cough', 'difficulty breathing'],
          severity: 'moderate',
          commonAge: ['child', 'adult'],
          riskFactors: ['allergies', 'exercise', 'cold air']
        },
        {
          name: 'Acute Bronchitis',
          symptoms: ['productive cough', 'fever', 'chest pain', 'fatigue', 'shortness of breath'],
          severity: 'moderate',
          commonAge: ['adult', 'child'],
          riskFactors: ['virus', 'smoking', 'pollution']
        },
        {
          name: 'Pneumonia',
          symptoms: ['productive cough', 'fever', 'chest pain', 'shortness of breath', 'chills'],
          severity: 'severe',
          commonAge: ['elderly', 'child'],
          riskFactors: ['infection', 'weak immunity', 'age']
        },
        {
          name: 'COPD',
          symptoms: ['shortness of breath', 'chronic cough', 'wheezing', 'chest tightness', 'fatigue'],
          severity: 'severe',
          commonAge: ['adult', 'elderly'],
          riskFactors: ['smoking', 'pollution', 'occupational']
        },
        {
          name: 'Pulmonary Embolism',
          symptoms: ['sudden shortness of breath', 'chest pain', 'rapid heart rate', 'dizziness', 'coughing blood'],
          severity: 'severe',
          commonAge: ['adult', 'elderly'],
          riskFactors: ['blood clots', 'surgery', 'prolonged sitting']
        },
        {
          name: 'Common Cold',
          symptoms: ['runny nose', 'cough', 'sneezing', 'sore throat', 'mild fever'],
          severity: 'mild',
          commonAge: ['child', 'adult'],
          riskFactors: ['virus', 'close contact', 'season']
        }
      ]
    }
  };

  // Logistic Regression Model Simulation
  static logisticRegressionPredict(symptomData) {
    const { organ, symptoms, duration, severity, age, gender } = symptomData;
    const diseases = this.medicalKnowledge[organ]?.diseases || [];
    
    return diseases.map(disease => {
      let score = 0;
      let matchedSymptoms = 0;
      
      // Symptom matching with logistic regression weights
      symptoms.forEach(symptom => {
        const symptomLower = symptom.toLowerCase();
        disease.symptoms.forEach(diseaseSymptom => {
          if (diseaseSymptom.includes(symptomLower) || symptomLower.includes(diseaseSymptom)) {
            score += 0.3; // Base symptom weight
            matchedSymptoms++;
          }
        });
      });
      
      // Duration weight (logistic regression feature)
      if (duration === 'chronic' && ['COPD', 'Asthma', 'Tinnitus'].includes(disease.name)) {
        score += 0.2;
      } else if (duration === 'acute' && ['Pneumonia', 'Bronchitis', 'Conjunctivitis'].includes(disease.name)) {
        score += 0.2;
      }
      
      // Severity correlation
      const severityMap = { 'mild': 1, 'moderate': 2, 'severe': 3 };
      const inputSeverity = severityMap[severity] || 1;
      const diseaseSeverity = severityMap[disease.severity] || 1;
      
      if (Math.abs(inputSeverity - diseaseSeverity) <= 1) {
        score += 0.15;
      }
      
      // Age factor
      if (disease.commonAge.includes(age)) {
        score += 0.1;
      }
      
      // Apply logistic function transformation
      const probability = Math.min(95, Math.max(5, (1 / (1 + Math.exp(-score * 8))) * 100));
      const confidence = Math.min(90, matchedSymptoms / Math.max(symptoms.length, 1) * 100);
      
      return {
        condition: disease.name,
        probability: Math.round(probability),
        confidence: Math.round(confidence)
      };
    }).sort((a, b) => b.probability - a.probability);
  }

  // Random Forest Model Simulation
  static randomForestPredict(symptomData) {
    const { organ, symptoms, duration, severity, age, additionalInfo } = symptomData;
    const diseases = this.medicalKnowledge[organ]?.diseases || [];
    
    return diseases.map(disease => {
      let treeScores = [];
      
      // Simulate 5 decision trees
      for (let tree = 0; tree < 5; tree++) {
        let treeScore = 0;
        
        // Tree 1: Focus on primary symptoms
        if (tree === 0) {
          symptoms.forEach(symptom => {
            if (disease.symptoms.slice(0, 3).some(ds => 
              ds.includes(symptom.toLowerCase()) || symptom.toLowerCase().includes(ds)
            )) {
              treeScore += 0.4;
            }
          });
        }
        
        // Tree 2: Age and severity focus
        if (tree === 1) {
          if (disease.commonAge.includes(age)) treeScore += 0.3;
          if (disease.severity === severity) treeScore += 0.3;
          symptoms.forEach(symptom => {
            if (disease.symptoms.some(ds => ds.includes(symptom.toLowerCase()))) {
              treeScore += 0.2;
            }
          });
        }
        
        // Tree 3: Risk factors and duration
        if (tree === 2) {
          if (duration === 'chronic' && ['COPD', 'Asthma', 'Glaucoma'].includes(disease.name)) {
            treeScore += 0.4;
          }
          if (additionalInfo.toLowerCase().includes('smoking') && 
              disease.riskFactors.includes('smoking')) {
            treeScore += 0.3;
          }
          symptoms.forEach(symptom => {
            if (disease.symptoms.some(ds => symptom.toLowerCase().includes(ds))) {
              treeScore += 0.15;
            }
          });
        }
        
        // Tree 4: Symptom combinations
        if (tree === 3) {
          const symptomCount = symptoms.filter(symptom =>
            disease.symptoms.some(ds => 
              ds.includes(symptom.toLowerCase()) || symptom.toLowerCase().includes(ds)
            )
          ).length;
          treeScore = Math.min(1, symptomCount / disease.symptoms.length);
        }
        
        // Tree 5: Weighted comprehensive
        if (tree === 4) {
          const symptomMatch = symptoms.filter(symptom =>
            disease.symptoms.some(ds => ds.includes(symptom.toLowerCase()))
          ).length / Math.max(symptoms.length, 1);
          
          const ageMatch = disease.commonAge.includes(age) ? 0.2 : 0;
          const severityMatch = disease.severity === severity ? 0.2 : 0;
          
          treeScore = symptomMatch * 0.6 + ageMatch + severityMatch;
        }
        
        treeScores.push(Math.max(0, Math.min(1, treeScore)));
      }
      
      // Average tree predictions (Random Forest ensemble)
      const avgScore = treeScores.reduce((sum, score) => sum + score, 0) / treeScores.length;
      const probability = Math.min(95, Math.max(5, avgScore * 100));
      
      // Calculate confidence based on tree agreement
      const variance = treeScores.reduce((sum, score) => sum + Math.pow(score - avgScore, 2), 0) / treeScores.length;
      const confidence = Math.min(90, Math.max(10, (1 - variance) * 100));
      
      return {
        condition: disease.name,
        probability: Math.round(probability),
        confidence: Math.round(confidence)
      };
    }).sort((a, b) => b.probability - a.probability);
  }

  // Gradient Boosting Model Simulation
  static gradientBoostingPredict(symptomData) {
    const { organ, symptoms, duration, severity, age, gender, additionalInfo } = symptomData;
    const diseases = this.medicalKnowledge[organ]?.diseases || [];
    
    return diseases.map(disease => {
      let baseScore = 0.1; // Initial prediction
      
      // Boosting iteration 1: Primary symptom matching
      let residual1 = 0;
      symptoms.forEach(symptom => {
        disease.symptoms.forEach(diseaseSymptom => {
          if (diseaseSymptom.includes(symptom.toLowerCase()) || 
              symptom.toLowerCase().includes(diseaseSymptom)) {
            residual1 += 0.25;
          }
        });
      });
      baseScore += residual1 * 0.1; // Learning rate 0.1
      
      // Boosting iteration 2: Age and demographic factors
      let residual2 = 0;
      if (disease.commonAge.includes(age)) residual2 += 0.3;
      if (gender === 'female' && ['Dry Eye Syndrome', 'Osteoporosis'].includes(disease.name)) {
        residual2 += 0.2;
      }
      if (gender === 'male' && ['COPD', 'Heart Disease'].includes(disease.name)) {
        residual2 += 0.2;
      }
      baseScore += residual2 * 0.12;
      
      // Boosting iteration 3: Severity and duration correlation
      let residual3 = 0;
      const severityWeight = { 'mild': 1, 'moderate': 2, 'severe': 3 };
      const inputSev = severityWeight[severity] || 1;
      const diseaseSev = severityWeight[disease.severity] || 1;
      
      if (Math.abs(inputSev - diseaseSev) === 0) residual3 += 0.4;
      else if (Math.abs(inputSev - diseaseSev) === 1) residual3 += 0.2;
      
      if (duration === 'chronic' && ['Asthma', 'COPD', 'Glaucoma', 'Tinnitus'].includes(disease.name)) {
        residual3 += 0.3;
      }
      baseScore += residual3 * 0.15;
      
      // Boosting iteration 4: Risk factors and additional info
      let residual4 = 0;
      const infoLower = additionalInfo.toLowerCase();
      disease.riskFactors.forEach(factor => {
        if (infoLower.includes(factor.toLowerCase())) {
          residual4 += 0.2;
        }
      });
      
      // Special conditions
      if (infoLower.includes('allerg') && disease.name.includes('Allergic')) {
        residual4 += 0.4;
      }
      if (infoLower.includes('smok') && ['COPD', 'Lung Cancer'].includes(disease.name)) {
        residual4 += 0.5;
      }
      baseScore += residual4 * 0.18;
      
      // Boosting iteration 5: Symptom pattern recognition
      let residual5 = 0;
      const symptomPatterns = {
        'respiratory': ['cough', 'shortness', 'wheezing', 'chest'],
        'visual': ['blurred', 'vision', 'light', 'see'],
        'auditory': ['hearing', 'ringing', 'buzz', 'deaf'],
        'pain': ['pain', 'ache', 'hurt', 'sore']
      };
      
      Object.entries(symptomPatterns).forEach(([pattern, keywords]) => {
        const patternMatch = symptoms.some(symptom => 
          keywords.some(keyword => symptom.toLowerCase().includes(keyword))
        );
        const diseasePattern = disease.symptoms.some(symptom =>
          keywords.some(keyword => symptom.includes(keyword))
        );
        
        if (patternMatch && diseasePattern) {
          residual5 += 0.3;
        }
      });
      baseScore += residual5 * 0.2;
      
      // Final probability calculation
      const probability = Math.min(95, Math.max(5, baseScore * 100));
      
      // Confidence based on boosting convergence
      const totalResidual = Math.abs(residual1) + Math.abs(residual2) + Math.abs(residual3) + 
                           Math.abs(residual4) + Math.abs(residual5);
      const confidence = Math.min(90, Math.max(15, (1 - totalResidual * 0.1) * 100));
      
      return {
        condition: disease.name,
        probability: Math.round(probability),
        confidence: Math.round(confidence)
      };
    }).sort((a, b) => b.probability - a.probability);
  }

  // Ensemble Method: Combine all three models
  static predict(symptomData) {
    // Get predictions from all three models
    const lrResults = this.logisticRegressionPredict(symptomData);
    const rfResults = this.randomForestPredict(symptomData);
    const gbResults = this.gradientBoostingPredict(symptomData);
    
    // Create ensemble predictions
    const diseaseMap = new Map();
    
    // Collect all unique diseases
    [...lrResults, ...rfResults, ...gbResults].forEach(result => {
      if (!diseaseMap.has(result.condition)) {
        diseaseMap.set(result.condition, {
          lr: { condition: result.condition, probability: 0, confidence: 0 },
          rf: { condition: result.condition, probability: 0, confidence: 0 },
          gb: { condition: result.condition, probability: 0, confidence: 0 }
        });
      }
    });
    
    // Fill in model results
    lrResults.forEach(result => {
      const entry = diseaseMap.get(result.condition);
      if (entry) entry.lr = result;
    });
    
    rfResults.forEach(result => {
      const entry = diseaseMap.get(result.condition);
      if (entry) entry.rf = result;
    });
    
    gbResults.forEach(result => {
      const entry = diseaseMap.get(result.condition);
      if (entry) entry.gb = result;
    });
    
    // Create ensemble predictions
    const ensemblePredictions = Array.from(diseaseMap.entries()).map(([condition, models]) => {
      // Weighted ensemble (Random Forest gets higher weight due to typically better performance)
      const lrWeight = 0.25;
      const rfWeight = 0.45;
      const gbWeight = 0.30;
      
      const ensembleProbability = Math.round(
        models.lr.probability * lrWeight +
        models.rf.probability * rfWeight +
        models.gb.probability * gbWeight
      );
      
      const ensembleConfidence = Math.round(
        models.lr.confidence * lrWeight +
        models.rf.confidence * rfWeight +
        models.gb.confidence * gbWeight
      );
      
      // Determine severity based on disease knowledge and probability
      const diseaseInfo = Object.values(this.medicalKnowledge)
        .flatMap(organ => organ.diseases)
        .find(disease => disease.name === condition);
      
      let severity = 'mild';
      if (diseaseInfo) {
        severity = diseaseInfo.severity;
      }
      
      // Adjust severity based on probability and symptoms
      if (ensembleProbability >= 85) {
        severity = severity === 'mild' ? 'moderate' : severity;
      }
      
      return {
        condition,
        probability: ensembleProbability,
        confidence: ensembleConfidence,
        severity,
        modelScores: {
          logisticRegression: models.lr.probability,
          randomForest: models.rf.probability,
          gradientBoosting: models.gb.probability
        }
      };
    });
    
    // Sort by ensemble probability
    return ensemblePredictions.sort((a, b) => b.probability - a.probability);
  }

  // Generate recommendations based on top prediction
  static generateRecommendations(topPrediction, symptomData) {
    const { condition, severity, probability } = topPrediction;
    const { organ } = symptomData;
    
    const recommendations = [];
    
    // General recommendations based on severity
    if (severity === 'severe' || probability >= 85) {
      recommendations.push('Seek immediate medical attention from a healthcare professional');
      recommendations.push('Do not delay in consulting a specialist');
    } else if (severity === 'moderate' || probability >= 70) {
      recommendations.push('Schedule an appointment with your healthcare provider');
      recommendations.push('Monitor symptoms closely for any changes');
    } else {
      recommendations.push('Consider consulting a healthcare provider if symptoms persist');
      recommendations.push('Practice self-care and monitor symptoms');
    }
    
    // Condition-specific recommendations
    const conditionRecommendations = {
      'Asthma': [
        'Use prescribed inhaler as directed',
        'Avoid known triggers and allergens',
        'Keep rescue medication readily available'
      ],
      'COPD': [
        'Follow prescribed medication regimen',
        'Avoid smoking and secondhand smoke',
        'Practice breathing exercises'
      ],
      'Pneumonia': [
        'Rest and stay well hydrated',
        'Take prescribed antibiotics as directed',
        'Use a humidifier to ease breathing'
      ],
      'Allergic Conjunctivitis': [
        'Avoid known allergens',
        'Use artificial tears for relief',
        'Apply cold compresses to reduce inflammation'
      ],
      'Dry Eye Syndrome': [
        'Use preservative-free artificial tears',
        'Take regular breaks from screen time',
        'Increase humidity in your environment'
      ],
      'Otitis Media': [
        'Apply warm compress to affected ear',
        'Take pain relievers as needed',
        'Keep ear dry and clean'
      ],
      'Earwax Blockage': [
        'Avoid inserting objects into ear',
        'Use ear drops to soften wax',
        'Consider professional ear cleaning'
      ]
    };
    
    const specificRecs = conditionRecommendations[condition] || [];
    recommendations.push(...specificRecs);
    
    // Organ-specific general advice
    if (organ === 'Eyes') {
      recommendations.push('Protect eyes from UV exposure');
      recommendations.push('Maintain good eye hygiene');
    } else if (organ === 'Ear') {
      recommendations.push('Protect ears from loud noises');
      recommendations.push('Keep ears clean and dry');
    } else if (organ === 'Lungs') {
      recommendations.push('Avoid air pollutants and irritants');
      recommendations.push('Stay active with appropriate exercise');
    }
    
    return recommendations.slice(0, 5); // Limit to 5 most relevant recommendations
  }
}
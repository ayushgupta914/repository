// API utility functions for communicating with the backend

const API_BASE_URL = 'http://localhost:5000/api';

// Helper function to get auth token from localStorage
const getAuthToken = () => {
  return localStorage.getItem('authToken');
};

// Helper function to set auth token in localStorage
const setAuthToken = (token) => {
  localStorage.setItem('authToken', token);
};

// Helper function to remove auth token from localStorage
const removeAuthToken = () => {
  localStorage.removeItem('authToken');
};

// Helper function to make authenticated requests
const authFetch = async (url, options = {}) => {
  const token = getAuthToken();
  
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(url, {
    ...options,
    headers,
  });

  if (response.status === 401) {
    // Token expired or invalid, clear it
    removeAuthToken();
    throw new Error('Authentication required. Please login again.');
  }

  return response;
};

// Authentication APIs
export const authAPI = {
  // Register a new user
  register: async (userData) => {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Registration failed');
      }

      // Save token
      setAuthToken(data.token);

      return data;
    } catch (error) {
      console.error('Registration error:', error);
      throw error;
    }
  },

  // Login user
  login: async (credentials) => {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(credentials),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Login failed');
      }

      // Save token
      setAuthToken(data.token);

      return data;
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    }
  },

  // Get current user info
  getCurrentUser: async () => {
    try {
      const response = await authFetch(`${API_BASE_URL}/auth/me`);

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch user data');
      }

      return data;
    } catch (error) {
      console.error('Get user error:', error);
      throw error;
    }
  },

  // Logout user (client-side only, just removes token)
  logout: () => {
    removeAuthToken();
  },

  // Check if user is authenticated
  isAuthenticated: () => {
    return !!getAuthToken();
  },
};

// Prediction APIs
export const predictionAPI = {
  // Save a new prediction
  save: async (predictionData) => {
    try {
      const response = await authFetch(`${API_BASE_URL}/predictions`, {
        method: 'POST',
        body: JSON.stringify(predictionData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to save prediction');
      }

      return data;
    } catch (error) {
      console.error('Save prediction error:', error);
      throw error;
    }
  },

  // Get all predictions for current user
  getAll: async () => {
    try {
      const response = await authFetch(`${API_BASE_URL}/predictions`);

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch predictions');
      }

      return data;
    } catch (error) {
      console.error('Get predictions error:', error);
      throw error;
    }
  },

  // Get a specific prediction
  getById: async (id) => {
    try {
      const response = await authFetch(`${API_BASE_URL}/predictions/${id}`);

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch prediction');
      }

      return data;
    } catch (error) {
      console.error('Get prediction error:', error);
      throw error;
    }
  },

  // Update prediction status
  updateStatus: async (id, status) => {
    try {
      const response = await authFetch(`${API_BASE_URL}/predictions/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to update prediction');
      }

      return data;
    } catch (error) {
      console.error('Update prediction error:', error);
      throw error;
    }
  },

  // Delete a prediction
  delete: async (id) => {
    try {
      const response = await authFetch(`${API_BASE_URL}/predictions/${id}`, {
        method: 'DELETE',
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to delete prediction');
      }

      return data;
    } catch (error) {
      console.error('Delete prediction error:', error);
      throw error;
    }
  },
};

// Health check API
export const healthAPI = {
  check: async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/health`);
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Health check error:', error);
      throw error;
    }
  },
};
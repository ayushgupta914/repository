# Symptom Disease Predictor - Backend API

This is the Node.js backend for the Symptom Disease Predictor application, using MongoDB for data persistence.

## Prerequisites

- Node.js (v14 or higher)
- MongoDB (installed and running locally)

## Installation

1. Navigate to the backend directory:
```bash
cd backend
```

2. Install dependencies:
```bash
npm install
```

3. Create a `.env` file (copy from `.env.example`):
```bash
cp .env.example .env
```

4. Update the `.env` file with your configuration if needed.

## Running the Server

### Development Mode (with auto-reload)
```bash
npm run dev
```

### Production Mode
```bash
npm start
```

The server will start on `http://localhost:5000` by default.

## MongoDB Setup

Make sure MongoDB is running on your local machine:

```bash
# Start MongoDB (on macOS with Homebrew)
brew services start mongodb-community

# Start MongoDB (on Linux)
sudo systemctl start mongod

# Start MongoDB (on Windows)
net start MongoDB
```

The database `symptom-predictor` will be created automatically when the server starts.

## API Endpoints

### Authentication

#### Register User
- **POST** `/api/auth/register`
- Body: `{ username, email, password, sex, bloodGroup, mobile }`
- Returns: JWT token and user data

#### Login User
- **POST** `/api/auth/login`
- Body: `{ email, password }`
- Returns: JWT token and user data

#### Get Current User
- **GET** `/api/auth/me`
- Headers: `Authorization: Bearer <token>`
- Returns: User data

### Predictions

#### Save Prediction
- **POST** `/api/predictions`
- Headers: `Authorization: Bearer <token>`
- Body: Prediction data (organ, symptoms, topCondition, etc.)
- Returns: Saved prediction

#### Get All Predictions
- **GET** `/api/predictions`
- Headers: `Authorization: Bearer <token>`
- Returns: Array of user's predictions

#### Get Specific Prediction
- **GET** `/api/predictions/:id`
- Headers: `Authorization: Bearer <token>`
- Returns: Single prediction

#### Update Prediction Status
- **PATCH** `/api/predictions/:id/status`
- Headers: `Authorization: Bearer <token>`
- Body: `{ status: "monitoring" | "resolved" | "pending" }`
- Returns: Updated prediction

#### Delete Prediction
- **DELETE** `/api/predictions/:id`
- Headers: `Authorization: Bearer <token>`
- Returns: Success message

### Health Check
- **GET** `/api/health`
- Returns: Server and database status

## Environment Variables

- `PORT`: Server port (default: 5000)
- `MONGODB_URI`: MongoDB connection string (default: mongodb://localhost:27017/symptom-predictor)
- `JWT_SECRET`: Secret key for JWT token generation (change in production!)

## Security Notes

⚠️ **Important for Production:**
1. Change the `JWT_SECRET` in your `.env` file
2. Use HTTPS in production
3. Implement rate limiting
4. Add input validation and sanitization
5. Use environment-specific configurations
6. Never commit `.env` file to version control

## Database Schema

### User Collection
- username (String, unique)
- email (String, unique)
- password (String, hashed)
- sex (String: male/female/other)
- bloodGroup (String)
- mobile (String)
- createdAt (Date)

### Prediction Collection
- userId (ObjectId, ref: User)
- date (String)
- time (String)
- organ (String)
- symptoms (Array of Strings)
- topCondition (String)
- probability (Number)
- severity (String: mild/moderate/severe)
- recommendations (Array of Strings)
- status (String: monitoring/resolved/pending)
- possibleDiseases (Array of Objects)
- hospitals (Array of Objects)
- location (String)
- createdAt (Date)

## Testing the API

You can test the API using tools like:
- Postman
- curl
- Thunder Client (VS Code extension)

Example curl command:
```bash
# Health check
curl http://localhost:5000/api/health

# Register user
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "email": "test@example.com",
    "password": "password123",
    "sex": "male",
    "bloodGroup": "O+",
    "mobile": "+1234567890"
  }'
```
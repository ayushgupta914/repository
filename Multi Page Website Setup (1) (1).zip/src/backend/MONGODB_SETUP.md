# MongoDB Integration Setup Guide

This application now uses MongoDB for storing user credentials and medical prediction reports.

## Prerequisites

- Node.js (v14 or higher)
- MongoDB (local installation or MongoDB Atlas account)

## Setup Instructions

### Option 1: Local MongoDB

1. **Install MongoDB locally:**
   - Download and install MongoDB Community Server from https://www.mongodb.com/try/download/community
   - Follow the installation instructions for your operating system

2. **Start MongoDB service:**
   ```bash
   # On macOS (using Homebrew)
   brew services start mongodb-community

   # On Linux
   sudo systemctl start mongod

   # On Windows
   # MongoDB should start automatically, or use Services app
   ```

3. **Configure the backend:**
   ```bash
   cd backend
   cp .env.example .env
   # The default MONGODB_URI should work for local MongoDB
   ```

### Option 2: MongoDB Atlas (Cloud)

1. **Create a free MongoDB Atlas account:**
   - Go to https://www.mongodb.com/cloud/atlas
   - Sign up for a free account
   - Create a new cluster (free tier M0 is sufficient)

2. **Get your connection string:**
   - Click "Connect" on your cluster
   - Choose "Connect your application"
   - Copy the connection string
   - Replace `<password>` with your database user password
   - Replace `<dbname>` with `symptom-predictor`

3. **Configure the backend:**
   ```bash
   cd backend
   cp .env.example .env
   # Edit .env and update MONGODB_URI with your Atlas connection string
   ```

## Starting the Application

1. **Install backend dependencies:**
   ```bash
   cd backend
   npm install
   ```

2. **Start the backend server:**
   ```bash
   # Development mode with auto-reload
   npm run dev

   # Or production mode
   npm start
   ```

   The server should start on http://localhost:5000

3. **Start the frontend:**
   ```bash
   # In the root directory (separate terminal)
   npm install
   npm run dev
   ```

   The frontend should be available at http://localhost:5173 (or similar)

## Testing the Integration

1. **Register a new account:**
   - Navigate to the Register page
   - Fill in all required fields
   - Click "Create Account"
   - You should be automatically logged in

2. **Use the Symptom Checker:**
   - Go to the Symptom Checker page
   - Select symptoms and analyze
   - The prediction should be automatically saved to MongoDB

3. **View your predictions:**
   - Go to Dashboard
   - Check the "Recent Analyses" tab
   - Your predictions should be loaded from MongoDB
   - You can download reports with hospital information

## Verifying MongoDB Data

### Using MongoDB Compass (GUI)

1. Download MongoDB Compass: https://www.mongodb.com/try/download/compass
2. Connect to your database
3. Browse collections: `users` and `predictions`

### Using MongoDB Shell

```bash
# Connect to local MongoDB
mongosh

# Switch to the database
use symptom-predictor

# View all users
db.users.find()

# View all predictions
db.predictions.find()
```

## API Endpoints

The backend provides the following endpoints:

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/me` - Get current user info (requires auth token)

### Predictions
- `POST /api/predictions` - Save new prediction (requires auth token)
- `GET /api/predictions` - Get all user predictions (requires auth token)
- `GET /api/predictions/:id` - Get specific prediction (requires auth token)
- `PATCH /api/predictions/:id/status` - Update prediction status (requires auth token)
- `DELETE /api/predictions/:id` - Delete prediction (requires auth token)

### Health Check
- `GET /api/health` - Check API and database status

## Security Notes

- **Never commit your .env file** - It contains sensitive credentials
- **Change JWT_SECRET** - Use a strong random string in production
- **Use HTTPS** - Always use HTTPS in production
- **MongoDB Atlas** - Enable IP whitelisting and use strong passwords
- **Rate Limiting** - Consider adding rate limiting for production

## Troubleshooting

### Connection Errors

If you see "MongoDB connection error":
- Check if MongoDB is running (local) or accessible (Atlas)
- Verify your connection string in .env
- Check firewall settings
- For Atlas: Ensure your IP is whitelisted

### Authentication Errors

If login/register fails:
- Check browser console for errors
- Verify backend is running on port 5000
- Check CORS settings if frontend is on different port
- Ensure JWT_SECRET is set in .env

### Data Not Saving

If predictions don't save:
- Check browser console for errors
- Verify you're logged in (check for auth token in localStorage)
- Check backend logs for errors
- Verify MongoDB connection is active

## Migration from Mock Data

The application previously used in-memory mock data. That code has been commented out in App.tsx. All new registrations and predictions are now stored in MongoDB.

If you had test accounts, you'll need to register them again through the registration page.

## Support

For issues or questions:
- Check the backend logs in the terminal
- Use browser DevTools to inspect network requests
- Verify MongoDB connection status via `/api/health` endpoint
